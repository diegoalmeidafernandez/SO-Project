#ifndef TYPES_H
#define TYPES_H

typedef struct command{
    int i;
    char comando[50];
    char opcion[50];
    char modo[50];
    char procedimiento[50];
}command;

typedef struct Tfile {
    int descriptor;
    char filename[20];
    char openningMode[2];
}Tfile;

typedef struct Tmemory {
    void *adress;
    int size;
    int clave;
    int decr;
    char type[10];
    char fileName[256];
    char permissions[10];
    char timestamp[20];
}TMemory;

#endif //TYPES_H