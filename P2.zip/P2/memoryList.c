#include "memoryList.h"
#include <stdlib.h>

void createEmptyMemoryList (memoryList *memoryList) {
    memoryList -> firstMemory = NULL;
    memoryList -> lastMemory = NULL;
}

void freeMemoryList (memoryList *memoryList) {
    memoryPos currentMemory = memoryList -> firstMemory;
    memoryPos nextMemory;

    while (currentMemory != NULL) {
        nextMemory = currentMemory -> next;
        free(currentMemory);
        currentMemory = nextMemory;
    }
    memoryList -> firstMemory = NULL;
    memoryList -> lastMemory = NULL;
}

bool isEmptyMemoryList (memoryList memoryList) {
    return (memoryList.firstMemory == NULL);
}

memoryPos firstMemory (memoryList memoryList) {
    return memoryList.firstMemory;
}

memoryPos lastMemory (memoryList memoryList) {
    return memoryList.lastMemory;
}

memoryPos previousMemory (memoryPos pos, memoryList memoryList) {
    memoryPos memoryPos = firstMemory(memoryList);

    while (memoryPos != NULL && nextMemory(memoryPos, memoryList) != pos) {
        memoryPos = nextMemory(memoryPos, memoryList);
    }
    return memoryPos;
}

memoryPos nextMemory (memoryPos memoryPos, memoryList memoryList) {
    return memoryPos -> next;
}

bool createMemoryNode (memoryPos *memoryPos) {
    *memoryPos = malloc(sizeof(struct memoryNode));
    return (*memoryPos != NULL);
}

void insertMemory (TMemory memory, memoryList *memoryList) {
    memoryPos pos;

    if (!createMemoryNode(&pos)) {
        return;
    }

    pos -> memory = memory;
    pos -> next = NULL;

    if (isEmptyMemoryList(*memoryList)) {
        memoryList -> firstMemory = pos;
        memoryList -> lastMemory = pos;
    }else {
        memoryList -> lastMemory -> next = pos;
        memoryList -> lastMemory = pos;
    }
}

void deleteMemory (memoryPos pos, memoryList *memoryList) {
    if (pos == firstMemory(*memoryList)) {
        if (firstMemory(*memoryList) == lastMemory(*memoryList)) {
            memoryList -> firstMemory = NULL;
            memoryList -> lastMemory = NULL;
        }else {
            memoryList -> firstMemory = nextMemory(pos, *memoryList);
        }
    }else {
        memoryPos previousPos = previousMemory(pos, *memoryList);
        if (pos == lastMemory(*memoryList)) {
            previousPos -> next = nextMemory(pos, *memoryList);
            memoryList -> lastMemory = previousPos;
        }else {
            previousPos -> next = nextMemory(pos, *memoryList);
        }
    }
    free(pos);
}

TMemory getMemory (memoryPos memoryPos, memoryList memoryList) {
    return memoryPos -> memory;
}

void typeMemory (memoryPos memoryPos, int memoryType) {
    switch (memoryType) {
        case 0: strcpy(memoryPos -> memory.type, "malloc");
            break;
        case 1: strcpy(memoryPos -> memory.type, "mapped");
            break;
        case 2: strcpy(memoryPos -> memory.type, "shared");
            break;
        default: perror("ERROR: Tipo de memoria no válido.");
            break;
    }
}