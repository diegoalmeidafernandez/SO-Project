#ifndef MEMORYLIST_H
#define MEMORYLIST_H
#include "types.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

typedef struct memoryNode *memoryPos;
struct memoryNode {
    TMemory memory;
    memoryPos next;
};

typedef struct memoryList {
    memoryPos firstMemory;
    memoryPos lastMemory;
}memoryList;

void createEmptyMemoryList (memoryList *memoryList);

void freeMemoryList (memoryList *memoryList);

bool isEmptyMemoryList (memoryList memoryList);

memoryPos firstMemory (memoryList memoryList);

memoryPos lastMemory (memoryList memoryList);

memoryPos previousMemory (memoryPos memoryPos, memoryList memoryList);

memoryPos nextMemory (memoryPos memoryPos, memoryList memoryList);

bool createMemoryNode (memoryPos *memoryPos);

void insertMemory (TMemory memory, memoryList *memoryList);

void deleteMemory (memoryPos memoryPos, memoryList *memoryList);

memoryPos searchMemoryKey (int clave, memoryList memoryList);

memoryPos searchMemoryMalloc (int n, memoryList memoryList);

memoryPos searchMemoryMapped (char *fileName, memoryList memoryList);

memoryPos searchMemoryAddress (void *adress, memoryList memoryList);

TMemory getMemory (memoryPos memoryPos, memoryList memoryList);

void typeMemory (TMemory memory, int memoryType);

void printMemoryList (int pid, memoryList memoryList);

#endif //MEMORYLIST_H
