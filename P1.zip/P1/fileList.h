#ifndef FILELIST_H
#define FILELIST_H

#include "types.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stddef.h>

typedef struct fileNode *filePos;
struct fileNode {
    int num;
    Tfile file;
    filePos next;
};

typedef struct fileList {
    filePos firstFile;
    filePos lastFile;
}fileList;

void createEmptyFileList (fileList *fileList);

void freeFileList (fileList *fileList);

bool isEmptyFileList (fileList fileList);

filePos firstFile (fileList fileList);

filePos lastFile (fileList fileList);

filePos previousFile (filePos filePos, fileList fileList);

filePos nextFile (filePos filePos, fileList fileList);

bool createFileNode (filePos *filePos);

void insertFile (Tfile file, fileList *fileList);

void deleteFile (filePos filePos, fileList *fileList);

filePos searchFileNum (int num, fileList fileList);

filePos searchFileName (char *fileName, fileList fileList);

void changeOMFile(char openingMode[2], filePos filePos, fileList *fileList);

Tfile getFile (filePos filePos, fileList fileList);

void printFileList (fileList fileList);
#endif //FILELIST_H