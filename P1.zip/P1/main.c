/*
 * Nombres y login: Diego Adrián Almeida Fernández (diego.almeida.fernandez@udc.es) y Juan Melón Domínguez (j.melon@udc.es)
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include "commandList.h"
#include "types.h"
#include "fileList.h"

#define MAX_TROZOS 10
#define MAX_STRING 100
#define MAX_COMMANDS 23
#define NAME0 "Diego Adrián Almeida Fernández"
#define NAME1 "Juan Melón Domínguez"
#define LOGIN0 "diego.almeida.fernandez@udc.es"
#define LOGIN1 "j.melon@udc.es"

//DECLARACIÓN DE FUNCIONES

void imprimirPrompt();

int TrocearCadena(char *cadena, char *trozos[]);

command leerEntrada();

void imprimirError(int opcion);

void authors(int opcion);

void pid();

void ppid();

void cd(int opcion, char dir[50]);

void openf(int opcion, char *file, fileList *fileList);

void closef(int desc, fileList *fileList);

void dupf(int desc, fileList *fileList);

void date(int opcion);

void historic(int opcion, int num, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList);

void infosys();

void help(int opcion, char *commands[MAX_COMMANDS]);

void makeFile(char *fileName);

void makeDir(char *dirName);

void listFile();

void cwd();

void listDir();

void recList();

void revList();

void erase();

void delRec();

int procesarEntrada(command command, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList);



/////////////////////////////////////////////////////////////////////////////////////////////

//CODIFICACION DE FUNCIONES

void imprimirPrompt() {
    printf("~$ ");
}

int TrocearCadena(char *cadena, char *trozos[]) {
    int i = 0;

    if ((trozos[i] = strtok(cadena, " \n\t")) == NULL) {
        return 0;
    }
    while ((trozos[++i] = strtok(NULL, " \n\t")) != NULL && i < MAX_TROZOS);
    return i;
}

command leerEntrada() {
    char entrada[100];
    char *trozos[3];
    command command;

    fgets(entrada, MAX_STRING, stdin);
    int i = TrocearCadena(entrada, trozos);

    command.i = i;
    if (i > 0) {
        if (i > 1) {
           if (i > 2) {// i = 3
               strcpy(command.comando, trozos[0]);
               strcpy(command.opcion, trozos[1]);
               strcpy(command.modo, trozos[2]);
           }else {// i = 2
               strcpy(command.comando, trozos[0]);
               strcpy(command.opcion, trozos[1]);
               strcpy(command.modo, "");
           }
        } else {// i = 1
            strcpy(command.comando, trozos[0]);
            strcpy(command.opcion, "");
            strcpy(command.modo, "");
         }
    }else {// i =0
        strcpy(command.comando, "");
        strcpy(command.opcion, "");
        strcpy(command.modo, "");
    }
    return command;
}

void imprimirError(int opcion) {
    if (opcion == 0) {
        perror("Comando no válido\n");
    }else {
        perror("Opción no válida\n");
    }
}

void authors(int opcion) {
    switch (opcion) {
        case 0:
            printf(NAME0 "\t" NAME1 "\n" LOGIN0 "\t" LOGIN1 "\n");
            break;
        case 1:
            printf(NAME0 "\t" NAME1 "\n");
            break;
        case 2:
            printf(LOGIN0 "\t" LOGIN1 "\n");
            break;
        default:
            imprimirError(1);
            break;
    }
}

void pid(){
    int pid = getpid();
    printf("%d\n", pid);
}

void ppid(){
    int ppid = getppid();
    printf("%d\n", ppid);
}

void cd(int opcion, char dir[50]){
    switch(opcion) {
        case 0 : cwd();
            break;
        case 1 : if (chdir(dir) == 0) {
                    char buffer1[1024];
                    char *currentcd = getcwd(buffer1, sizeof(buffer1));
                    printf("%s\n", currentcd);
                }else {
                    imprimirError(1);
                }
            break;
        default : imprimirError(1);
            break;
    }
}

void openf(int opcion, char *file, fileList *fileList) {

    Tfile fichero;
    strcpy(fichero.filename, file);
    char buffer[1024];
    char *path = getcwd(buffer, sizeof(buffer));
    if (path == NULL) {
        perror("Error al obtener el directorio de trabajo actual\n");
        return;
    }
    path = strcat(path, "/");
    char *filepath = strcat(path, file);

       switch (opcion) {
        case 0: //sin modo
            cd(0, "/proc/self/fd");
            printFileList(*fileList);
            break;
        case 1: //cr
            int descr = open(filepath, O_CREAT | O_WRONLY, 0644);
            if (descr != -1) {
                printf("El archivo %s ha sido creado correctamente en la ruta:\t%s\n", fichero.filename, filepath);
                strcpy(fichero.openningMode, "cr");
                fichero.descriptor = descr;
                insertFile(fichero, fileList);
            }else {
                perror("Error al abrir el archivo\n");
            }
            break;
        case 2: //ap
            if(searchFileName(file, *fileList) != NULL) {
                int descap = open(filepath, O_APPEND | O_WRONLY);
                if (descap != -1) {
                    printf("Archivo abierto en modo append\n");
                    changeOMFile("ap", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al abrir el archivo en modo append\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 3: //ex
            if (searchFileName(file, *fileList) == NULL) {
                int decex = open(filepath, O_CREAT | O_EXCL | O_WRONLY, 0644);
                if (decex != -1) {
                    printf("El archivo %s ha sido creado correctamente en la ruta:\t%s\n", fichero.filename, filepath);
                    strcpy(fichero.openningMode, "ex");
                    fichero.descriptor = decex;
                    insertFile(fichero, fileList);
                }else {
                    perror("Error al crear el archivo\n");
                }
            }else {
                perror("El archivo ya existe\n");
            }
            break;
        case 4: //ro
            if (searchFileName(file, *fileList) != NULL) {
                int descro = open(filepath, O_RDONLY);
                if (descro != -1) {
                    changeOMFile("ro", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al abrir el archivo en modo lectura\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 5: //rw
            if (searchFileName(file, *fileList) != NULL) {
                int descrw = open(filepath, O_RDWR);
                if (descrw != -1) {
                    changeOMFile("rw", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al abrir el archivo en modo lectura/escritura\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 6: //wo
            if (searchFileName(file, *fileList) != NULL) {
                int descwo = open(filepath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if (descwo != -1) {
                    printf("Archivo abierto en modo escritura, contenido truncado\n");
                    strcpy(fichero.openningMode, "wo");
                    fichero.descriptor = descwo;
                    insertFile(fichero, fileList);
                }else {
                    perror("Error al abrir el archivo en modo escritura\n");
                }
            }else {
                perror("EL archivo no existe\n");
            }
            break;
        case 7: //tr
            if (searchFileName(file, *fileList) != NULL) {
                int desctr = open(filepath, O_TRUNC | O_WRONLY);
                if (desctr != -1) {
                    printf("El contenido del archivo ha sido borrado\n");
                    changeOMFile("tr", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al truncar el archivo\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        default:
            if (strcmp(file, "a") == 0) {
                imprimirError(1);
            }else {
                imprimirError(0);
            }
    }
}

void closef(int desc, fileList *fileList) {
   filePos filePos = searchFileNum(desc, *fileList);
    if (filePos == NULL){
        perror("No se puede acceder al archivo\n");
    }else {
        deleteFile(filePos, fileList);
        printf("El archivo se ha cerrado correctamente\n");
    }
}

void dupf(int desc, fileList *fileList) {
    filePos filePos = searchFileNum(desc, *fileList);
    if (filePos == NULL) {
        perror("No se puede acceder al archivo\n");
    }else {
        insertFile(getFile(filePos, *fileList), fileList);
        printf("El archivo se ha duplicado correctamente\n");
    }
}

void date(int opcion) {
    time_t t = time(NULL);
    struct tm *tm_info = localtime(&t);

    char buffer[80];

    switch (opcion) {
        case 0:
            strftime(buffer, sizeof(buffer), "Fecha:\t%d/%m/%Y\nHora:\t%H:%M:%S", tm_info);
            printf("%s\n", buffer);
            break;
        case 1:
            strftime(buffer, sizeof(buffer), "%H:%M:%S", tm_info);
            printf("Hora:\t%s\n", buffer);
            break;
        case 2:
            strftime(buffer, sizeof(buffer), "%d/%m/%Y", tm_info);
            printf("Fecha:\t%s\n", buffer);
            break;
        default:
            imprimirError(1);
            break;
    }
}

void historic(int opcion, int num, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList) {
    switch (opcion) {
        case 0: printCommandList(*commandList);
            break;
        case 1: commandPos pos = searchCommand(num, *commandList);
                if (pos != NULL) {
                    command command = getCommand(pos, *commandList);
                    procesarEntrada(command, commands, commandList, fileList);
                }
            break;
        case 2:
                printLastNCommands(num, *commandList);
            break;
        default: imprimirError(1);
            break;
    }
}

void infosys() {
    struct utsname buffer;

    if (uname(&buffer) != 0) {
        perror("uname");
        return;
    }

    printf("Sistema operativo: %s\n", buffer.sysname);
    printf("Nombre del nodo:   %s\n", buffer.nodename);
    printf("Versión del kernel:%s\n", buffer.release);
    printf("Versión del SO:    %s\n", buffer.version);
    printf("Arquitectura:      %s\n", buffer.machine);
}

void help(int opcion, char *commands[MAX_COMMANDS]) {
    switch (opcion) {
        case 0:
            printf(
                "%s:\tImprime los nombres y logins de los autores del programa.\n%s -l:\tImprime solamente los logins.\n%s -n:\tImprime solamente los nombres.\n",
                commands[0], commands[0], commands[0]);
        break;
        case 1:
            printf("%s:\tImprime el PID del proceso ejecutandose en la shell.\n", commands[1]);
        break;
        case 2:
            printf("%s:\tImprime el PID del proceso padre de la shell.\n", commands[2]);
        break;
        case 3:
            printf("%s [dir]:\tCambia el directorio actual de trabajo de la shell al deseado.\n", commands[3]);
        break;
        case 4:
            printf(
                "%s:\tImprime la fecha actual en formato DD/MM/YYYY y la hora actual en formato hh:mm:ss.\n%s -d:\tImprime la fecha actual en formato DD/MM/YYYY.\n%s -t:\tImprime la hora actual en formato hh:mm:ss.\n",
                commands[4], commands[4], commands[4]);
        break;
        case 5:
            printf(
                "%s:\tImprime todos los comandos que se han introducido con su número de orden.\n%s N:\tRepite el comando número N.\n%s -N:\tImprime solamente los últimos N-comandos.\n",
                commands[5], commands[5], commands[5]);
        break;
        case 6:
            printf("%s [file] mode:\tAbre un archivo y lo añade.\n", commands[6]);
        break;
        case 7:
            printf("%s [df]:\tCierra el descriptor de archivo df y elimina el elemento correspondiente de la lista.\n", commands[7]);
        break;
        case 8:
            printf("%s [df]:\tDuplica el descriptor de archivo.\n", commands[8]);
        break;
        case 9:
            printf("%s:\tImprime la información de la máquina que está ejecutando la shell.\n", commands[9]);
        break;
        case 10:
            printf("%s:\t Muestra por pantalla una lista de los comandos disponibles.\n%s [cmd]:\tBrinda una pequeña descripción del uso de cada comando.\n", commands[10], commands[10]);
        break;
        case 11:
            printf("%s:\tCierra el terminal.\n", commands[11]);
        break;
        case 12:
            printf("%s:\tCierra el terminal.\n", commands[12]);
        break;
        case 13:
            printf("%s:\tCierra el terminal.\n", commands[13]);
        break;
        case 14:
            printf("%s:\tCrea un fichero.\n", commands[14]);
        break;
        case 15:
            printf("%s:\tCrea un directorio.\n", commands[15]);
        break;
        case 16:
            printf("%s:\tDevuelve información de archivos o de directorios.\n", commands[16]);
        break;
        case 17:
            printf("%s:\tImprime el directorio actual de trabajo.\n", commands[17]);
        break;
        case 18:
            printf("%s:\tLista el contenido de los directorios.\n", commands[18]);
        break;
        case 19:
            printf("%s:\tLista directorios de forma recursiva (subdirectorios después).\n", commands[19]);
        break;
        case 20:
            printf("%s:\tLista directorios de forma recursiva (subdirectorios antes).\n", commands[20]);
        break;
        case 21:
            printf("%s:\tElimina archivos y/o directorios vacíos.\n",commands[21]);
        break;
        case 22:
            printf("%s:\tElimina archivos y/o directorios vacíos de forma recursiva.\n",commands[22]);
        break;
        case 23:
            printf("Comandos disponibles:\n");
            for (int i = 0; i < MAX_COMMANDS; i++){
                printf("%s\n", commands[i]);
            }
        break;
        default:
            imprimirError(1);
        break;
    }
}

void makeFile(char *fileName) {
    char buffer[1024];
    char *path = getcwd(buffer, sizeof(buffer));

    if (path == NULL) {
        perror("No se ha podido obtener el directorio actual de trabajo.\n");
    }else {
        path = strcat(path, "/");
        char *filepath = strcat(path, fileName);

        int descr = open(filepath, O_CREAT | O_WRONLY, 0644);
        if (descr != -1) {
            printf("El archivo %s se ha creado correctamente en la ruta %s\n", fileName, filepath);
        }else {
            perror("Error al crear el archivo.\n");
        }
    }
}

void makeDir(char *dirName) {
    char buffer[1024];
    char *path = getcwd(buffer, sizeof(buffer));

    if (path == NULL) {
        perror("No se ha podido obtener el directorio actual de trabajo.\n");
    }else {
        path = strcat(path, "/");
        char *dirpath = strcat(path, dirName);

        int dir = mkdir(dirName, 0755);
        if (dir == 0) {
            printf("El directorio %s se ha creado correctamente en la ruta %s\n", dirName, dirpath);
        }else {
            perror("Error al crear el directorio.\n");
        }
    }
}

void listFile(){}

void cwd() {
    char buffer[1024];
    char *cwd = getcwd(buffer, sizeof(buffer));

    if (cwd == NULL) {
        perror("Error obteniendo el directorio actual.\n");
    }else {
        printf("%s\n", cwd);
    }
}

void listDir(){}

void recList(char *dir) { // ARREGLAR QUE YA ESTA CASI
    struct dirent *entry;
    DIR *d = opendir(dir);

    if (d == NULL) {
        perror("No se pudo abrir el directorio");
        return;
    }

    while ((entry = readdir(d)) != NULL) {
        char path[1024];
        struct stat info;

        if (strcmp(entry->d_name, ".") != 0 || strcmp(entry->d_name, "..") != 0) {
            snprintf(path, sizeof(path), "%s/%s", dir, entry->d_name);

            if (stat(path, &info) == 0) {
                if (S_ISDIR(info.st_mode)) {
                    printf("Directorio: %s\n", path);
                    recList(path);
                } else {
                    printf("a\n");
                }
            } else {
                perror("Error obteniendo información del archivo");
            }
        }
    }
    closedir(d);
}

void revList(char *dir) {}

void erase(){}

void delRec(){}

int procesarEntrada(command command, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList) {
    int i = 0;

    if(strcmp(command.comando, "a") == 0) {
        cd(1, "/home/diego/Escritorio");
        //cd(1, "/home/juan/Escritorio");
        return i;
    }

    if (strcmp(command.comando, commands[0]) == 0) {
        if (command.i == 1) {
            authors(0);
        } else if (strcmp(command.opcion, "-n") == 0) {
            authors(1);
        } else if (strcmp(command.opcion, "-l") == 0) {
            authors(2);
        } else {
            authors(3);
        }
        insertCommand(command, commandList);
        return i;
    } //authors

    if (strcmp(command.comando, commands[1]) == 0){
        if (command.i == 1){
            pid();
            insertCommand(command, commandList);
        }else{
            imprimirError(1);
        }
        return i;
    } //pid

    if (strcmp(command.comando, commands[2]) == 0){
        if (command.i == 1){
            ppid();
            insertCommand(command, commandList);
        }else{
            imprimirError(1);
        }
        return i;
    } //ppid

    if (strcmp(command.comando, commands[3]) == 0) {
        if (command.i == 1) {
            cd(0, command.opcion);
            insertCommand(command, commandList);
        }else if (command.i == 2) {
            cd(1, command.opcion);
            insertCommand(command, commandList);
        }else {
            cd(2, command.opcion);
        }
        return i;
    } //cd

    if (strcmp(command.comando, commands[4]) == 0) { // date
        if (command.i == 1) {
            date(0);
        }else {
            if (strcmp(command.opcion, "-t") == 0) {
                date(1);
            }else {
                if (strcmp(command.opcion, "-d") == 0) {
                    date(2);
                }else {
                    date(3);
                }
            }
        }
        insertCommand(command, commandList);
        return i;
    } //date

    if (strcmp(command.comando, commands[5]) == 0) { // historic
        if (command.i == 1) {
            historic(0, 0, commands, commandList, fileList);
        }else {
            int num;
            if (sscanf(command.opcion, "%d", &num) == 1) {
                if (num >= 0) {
                    historic(1, num, commands, commandList, fileList);
                    insertCommand(command, commandList);
                }else {
                    historic(2, num, commands, commandList, fileList);
                    insertCommand(command, commandList);
                }
            }else {
                historic(3, num, commands, commandList, fileList);
            }
        }
        return i;
    } //historic

    if (strcmp(command.comando, commands[6]) == 0) {
       if (command.i == 1) {
           openf(0, "",fileList);
       }else if (command.i == 3) {
           if(strcmp(command.modo, "cr") == 0) {
               openf(1, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ap") == 0) {
               openf(2, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ex") == 0) {
               openf(3, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ro") == 0) {
               openf(4, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "rw") == 0) {
               openf(5, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "wo") == 0) {
               openf(6, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "tr") == 0) {
               openf(7, command.opcion, fileList);
               insertCommand(command, commandList);
           }else {
               openf(8, "a", fileList);
           }
       }else {
           openf(8, "b", fileList);
       }
        return i;
    } //open

    if (strcmp(command.comando, commands[7]) == 0) {
        if (command.i == 2) {
            int desc;
            sscanf(command.opcion, "%d", &desc);
            closef(desc, fileList);
            insertCommand(command, commandList);
        }else {
            imprimirError(1); //
        }
        return i;
    } //close

    if (strcmp(command.comando, commands[8]) == 0) {
        if (command.i == 2) {
            int desc;
            sscanf(command.opcion, "%d", &desc);
            dupf(desc, fileList);
            insertCommand(command, commandList);
        }else {
            imprimirError(0);
        }
        return i;
    } //dup

    if (strcmp(command.comando, commands[9]) == 0) {
        if (command.i == 1) {
            infosys();
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    } //infosys

    if (strcmp(command.comando, commands[10]) == 0) {
        if (command.i == 1) {
            help(23, commands);
        }else {
            for (int j = 0; j < MAX_COMMANDS; j++) {
                if (strcmp(command.opcion, commands[j]) == 0) {
                    help(j, commands);
                    return i;
                }
            }
            printf("Opción no válida.\n");
        }
        insertCommand(command, commandList);
        return i;
    } //help

    if ((strcmp(command.comando, commands[11]) == 0) || // exit
       (strcmp(command.comando, commands[12]) == 0) || // quit
       (strcmp(command.comando, commands[13]) == 0)) { //bye
        if (command.i == 1) {
            i = 1;
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    }

    if (strcmp(command.comando, commands[14]) == 0) {
        if (command.i == 2) {
            makeFile(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    } // makefile

    if (strcmp(command.comando, commands[15]) == 0) {
        if (command.i == 2) {
            makeDir(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    } // makedir

    if (strcmp(command.comando, commands[16]) == 0) {
        if(command.i == 1) {
            listFile();
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    } // listFile

    if (strcmp(command.comando, commands[17]) == 0) {
        if (command.i == 1) {
            cwd();
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    } // cwd

    if (strcmp(command.comando, commands[18]) == 0) {
        if (command.i == 2) {
            listDir(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    } // listdir

    if (strcmp(command.comando, commands[19]) == 0) {
        if (command.i == 2) {
            recList(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
        return i;
    } // reclist

    if (strcmp(command.comando, commands[20]) == 0) {
        if (command.i == 2) {
            revList(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
    } // revlist

    if (strcmp(command.opcion, commands[21]) == 0) {
        if (command.i == 2) {
            erase(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
    } // erase

    if (strcmp(command.comando, commands[22]) == 0) {
        if (command.i == 2) {
            delRec(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(1);
        }
    } // delRec

    imprimirError(0);
    return i;
}

int main() {
    bool terminado = false;
    commandList commandList;
    createEmptyCommandList(&commandList);
    fileList fileList;
    createEmptyFileList(&fileList);

    char *commands[MAX_COMMANDS] = {
        "authors", "pid", "ppid", "cd", "date", "historic", "open", "close",
        "dup", "infosys", "help", "exit", "quit", "bye", "makefile", "makedir",
        "listfile", "cwd", "listdir", "reclist", "revlist", "erase", "delrec"
    };

    while (!terminado) {
        imprimirPrompt();
        command command = leerEntrada();

        if (command.i > 0) {
            int i = procesarEntrada(command, commands, &commandList, &fileList);

            if (i == 1) {
                terminado = true;
            }
        }
    }
    freeCommandList(&commandList);
    return 0;
}
