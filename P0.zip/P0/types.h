#ifndef TYPES_H
#define TYPES_H

typedef struct command{
    int i;
    char comando[10];
    char opcion[50];
    char modo[50];
}command;

typedef struct Tfile {
    int descriptor; //fileno(file);
    char filename[20];
    char openningMode[2];
}Tfile;

#endif //TYPES_H