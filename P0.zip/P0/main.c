/**
 * Nombres y login: Diego Adrián Almeida Fernández (diego.almeida.fernandez@udc.es) y Juan Melón Domínguez (j.melon@udc.es)
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>

#include "commandList.h"
#include "types.h"
#include <sys/utsname.h>

#include "fileList.h"

#define MAX_TROZOS 10
#define MAX_STRING 100
#define MAX_COMMANDS 14
#define NAME0 "Diego Adrián Almeida Fernández"
#define NAME1 "Juan Melón Domínguez"
#define LOGIN0 "diego.almeida.fernandez@udc.es"
#define LOGIN1 "j.melon@udc.es"

//DECLARACIÓN DE FUNCIONES

void imprimirPrompt();

int TrocearCadena(char *cadena, char *trozos[]);

command leerEntrada();

void imprimirError(int opcion);

void authors(int opcion);

void pid();

void ppid();

void cd(int opcion, char dir[50]);

bool existsFile(char *file);

void openf(int opcion, char *file, fileList *fileList);

void closef(int desc, fileList *fileList);

void dupf(int desc, fileList *fileList);

void date(int opcion);

void historic(int opcion, int num, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList);

void infosys();

void help(int opcion, char *commands[MAX_COMMANDS]);

int procesarEntrada(command command, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList);

/////////////////////////////////////////////////////////////////////////////////////////////

//CODIFICACION DE FUNCIONES

void imprimirPrompt() {
    printf("~$ ");
}

int TrocearCadena(char *cadena, char *trozos[]) {
    int i = 0;

    if ((trozos[i] = strtok(cadena, " \n\t")) == NULL) {
        return 0;
    }
    while ((trozos[++i] = strtok(NULL, " \n\t")) != NULL && i < MAX_TROZOS);
    return i;
}

command leerEntrada() {
    char entrada[100];
    char *trozos[3];
    command command;

    fgets(entrada, MAX_STRING, stdin);
    int i = TrocearCadena(entrada, trozos);

    command.i = i;
    if (i > 0) {
        if (i > 1) {
           if (i > 2) {// i = 3
               strcpy(command.comando, trozos[0]);
               strcpy(command.opcion, trozos[1]);
               strcpy(command.modo, trozos[2]);
           }else {// i = 2
               strcpy(command.comando, trozos[0]);
               strcpy(command.opcion, trozos[1]);
               strcpy(command.modo, "");
           }
        } else {// i = 1
            strcpy(command.comando, trozos[0]);
            strcpy(command.opcion, "");
            strcpy(command.modo, "");
         }
    }else {// i =0
        strcpy(command.comando, "");
        strcpy(command.opcion, "");
        strcpy(command.modo, "");
    }
    return command;
}

void imprimirError(int opcion) {
    if (opcion == 0) {
        perror("Comando no válido\n");
    }else {
        perror("Opción no válida\n");
    }
}

void authors(int opcion) {
    switch (opcion) {
        case 0:
            printf(NAME0 "\t" NAME1 "\n" LOGIN0 "\t" LOGIN1 "\n");
            break;
        case 1:
            printf(NAME0 "\t" NAME1 "\n");
            break;
        case 2:
            printf(LOGIN0 "\t" LOGIN1 "\n");
            break;
        default:
            imprimirError(1);
            break;
    }
}

void pid(){
    int pid = getpid();
    printf("%d\n", pid);
}

void ppid (){
    int ppid = getppid();
    printf("%d\n", ppid);
}

void cd(int opcion, char dir[50]){
    switch(opcion) {
        case 0 : char buffer0[1024];
                 char *cd = getcwd(buffer0, sizeof(buffer0));
                 if (cd == NULL) {
                     perror("Error obtenido el directorio actual");
                 }else {
                     printf("%s\n", cd);
                 }
            break;
        case 1 : if (chdir(dir) == 0) {
                    char buffer1[1024];
                    char *currentcd = getcwd(buffer1, sizeof(buffer1));
                    printf("%s\n", currentcd);
                }else {
                    imprimirError(1);
                }
            break;
        case 2 : imprimirError(1);
    }
}

bool existsFile(char *file) {
    return (file != NULL);
}

void openf(int opcion, char *file, fileList *fileList) {

    DIR *dir;;
    Tfile fichero;
    strcpy(fichero.filename, file);
    char buffer[1024];
    char *path = getcwd(buffer, sizeof(buffer));
    path = strcat(path, "/");
    char *filepath = strcat(path, file);

       switch (opcion) {
        case 0: //sin modo
            printFileList(*fileList);
            //dir = opendir("/proc/self/fd/");
            break;
        case 1: //cr
            //file = fopen(path, "w");
            //int desccr = fileno(file);
            int desccr = open(path, O_CREAT);
            if (existsFile(file)) {
                printf("El archivo %s ha sido creado correctamente en la ruta:\t%s\n", fichero.filename, filepath);
                strcpy(fichero.openningMode, "cr");
                //strcpy(fichero.descriptor, desccr);
                insertFile(fichero, fileList);
            }else {
                perror("Error al crear el archivo\n");
            }
            break;
        case 2: //ap
            if (existsFile(file)) {
                int descap = open(path, O_APPEND);
                printf( "Archivo actualizado");
                strcpy(fichero.openningMode, "ap");
                //strcpy(fichero.descriptor, descap);
                insertFile(fichero, fileList);
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 3: //ex
            if (existsFile(file)) {
                int decex = open(path, O_EXCL);
                printf("El archivo %s ha sido creado correctamente en la ruta:\t%s\n", fichero.filename, filepath);
                strcpy(fichero.openningMode, "ex");
                //strcpy(fichero.descriptor, decex);
                insertFile(fichero, fileList);
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 4: //ro
            if (existsFile(file)) {
                int descro = open(path, O_RDONLY);
                strcpy(fichero.openningMode, "ro");
                //strcpy(fichero.descriptor, descro);
                insertFile(fichero, fileList);
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 5: //rw
            if (existsFile(file)) {
                int descrw = open(path, O_RDWR);
                strcpy(fichero.openningMode, "rw");
                //strcpy(fichero.descriptor, descrw);
                insertFile(fichero, fileList);
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 6: //wo
            if (existsFile(file)) {
                int descwo = open(path, O_WRONLY);
                strcpy(fichero.openningMode, "wo");
                //strcpy(fichero.descriptor, descwo);
                insertFile(fichero, fileList);
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case 7: //tr
            if (existsFile(file)) {
                int desctr = open(path, O_TRUNC);
                printf("El contenido del archivo ha sido borrado\n");
                strcpy(fichero.openningMode, "tr");
                //strcpy(fichero.descriptor, desctr);
                insertFile(fichero, fileList);
            }else {
                perror("El archivo no existe\n");
            }
            break;
        default:
            if (strcmp(file, "a") == 0) {
                imprimirError(1);
            }else {
                imprimirError(0);
            }
    }
}

void closef(int desc, fileList *fileList) {
    if (searchFile( desc, *fileList) != NULL) {
        //deleteFile(desc, *fileList);
    }else {
        perror("No se encuentra el archivo\n");
    }
}

void dupf(int desc, fileList *fileList) {

    if (searchFile(desc, *fileList) != NULL) {
        Tfile *file = searchFile(desc, *fileList);
        Tfile *newFile;
        newFile->descriptor = dup(file);
        strcpy(newFile->filename,file->filename );
        openf(1, newFile, fileList);
    }else {
        perror("No se encuentra el archivo\n");
    }

}

void date(int opcion) {
    time_t t = time(NULL);
    struct tm *tm_info = localtime(&t);

    char buffer[80];

    switch (opcion) {
        case 0:
            strftime(buffer, sizeof(buffer), "Fecha:\t%d/%m/%Y\nHora:\t%H:%M:%S", tm_info);
            printf("%s\n", buffer);
            break;
        case 1:
            strftime(buffer, sizeof(buffer), "%H:%M:%S", tm_info);
            printf("Hora:\t%s\n", buffer);
            break;
        case 2:
            strftime(buffer, sizeof(buffer), "%d/%m/%Y", tm_info);
            printf("Fecha:\t%s\n", buffer);
            break;
        default:
            imprimirError(1);
            break;
    }
}

void historic(int opcion, int num, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList) {
    switch (opcion) {
        case 0: printCommandList(*commandList);
            break;
        case 1: commandPos pos = searchCommand(num, *commandList);
                if (pos != NULL) {
                    command command = getCommand(pos, *commandList);
                    procesarEntrada(command, commands, commandList, fileList);
                }
            break;
        case 2:
                printLastNCommands(num, *commandList);
            break;
        default: imprimirError(1);
            break;
    }
}

void infosys() {
    struct utsname buffer;

    if (uname(&buffer) != 0) {
        perror("uname");
        return;
    }

    printf("Sistema operativo: %s\n", buffer.sysname);
    printf("Nombre del nodo:   %s\n", buffer.nodename);
    printf("Versión del kernel:%s\n", buffer.release);
    printf("Versión del SO:    %s\n", buffer.version);
    printf("Arquitectura:      %s\n", buffer.machine);
}

void help(int opcion, char *commands[MAX_COMMANDS]) {
    switch (opcion) {
        case 0:
            printf(
                "%s:\tImprime los nombres y logins de los autores del programa.\n%s -l:\tImprime solamente los logins.\n%s -n:\tImprime solamente los nombres.\n",
                commands[0], commands[0], commands[0]);
        break;
        case 1:
            printf("%s:\tImprime el PID del proceso ejecutandose en la shell.\n", commands[1]);
        break;
        case 2:
            printf("%s:\tImprime el PID del proceso padre de la shell.\n", commands[2]);
        break;
        case 3:
            printf("%s [dir]:\tCambia el directorio actual de trabajo de la shell al deseado.\n", commands[3]);
        break;
        case 4:
            printf(
                "%s:\tImprime la fecha actual en formato DD/MM/YYYY y la hora actual en formato hh:mm:ss.\n%s -d:\tImprime la fecha actual en formato DD/MM/YYYY.\n%s -t:\tImprime la hora actual en formato hh:mm:ss.\n",
                commands[4], commands[4], commands[4]);
        break;
        case 5:
            printf(
                "%s:\tImprime todos los comandos que se han introducido con su número de orden.\n%s N:\tRepite el comando número N.\n%s -N:\tImprime solamente los últimos N-comandos.\n",
                commands[5], commands[5], commands[5]);
        break;
        case 6:
            printf("%s [file] mode:\tAbre un archivo y lo añade.\n", commands[6]);
        break;
        case 7:
            printf("%s [df]:\tCierra el descriptor de archivo df y elimina el elemento correspondiente de la lista.\n", commands[7]);
        break;
        case 8:
            printf("%s [df]:\tDuplica el descriptor de archivo.\n", commands[8]);
        break;
        case 9:
            printf("%s:\tImprime la información de la máquina que está ejecutando la shell.\n", commands[9]);
        break;
        case 10:
            printf("%s:\t Muestra por pantalla una lista de los comandos disponibles.\n%s [cmd]:\tBrinda una pequeña descripción del uso de cada comando.\n", commands[10], commands[10]);
        break;
        case 11:
            printf("%s:\tCierra el terminal.\n", commands[11]);
        break;
        case 12:
            printf("%s:\tCierra el terminal.\n", commands[12]);

        break;
        case 13:
            printf("%s:\tCierra el terminal.\n", commands[13]);

        break;
        case 14:
            printf("Comandos disponibles:\n");
        for (int i = 0; i < MAX_COMMANDS; i++) {
            printf("%s\n", commands[i]);
        }
        break;
        default:
            imprimirError(1);
        break;
    }
}

int procesarEntrada(command command, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList) {
    int i = 0;

    if (strcmp(command.comando, commands[0]) == 0) {
        if (command.i == 1) {
            authors(0);
        } else if (strcmp(command.opcion, "-n") == 0) {
            authors(1);
        } else if (strcmp(command.opcion, "-l") == 0) {
            authors(2);
        } else {
            authors(3);
        }
        insertCommand(command, commandList);
        return i;
    } //authors

    if (strcmp(command.comando, commands[1]) == 0){
        if (command.i == 1){
            pid();
            insertCommand(command, commandList);
        }else{
            imprimirError(0);
        }
        return i;
    } //pid

    if (strcmp(command.comando, commands[2]) == 0){
        if (command.i == 1){
            ppid();
            insertCommand(command, commandList);
        }else{
            imprimirError(0);
        }
        return i;
    } //ppid

    if (strcmp(command.comando, commands[3]) == 0) {
        if (command.i == 1) {
            cd(0, command.opcion);
            insertCommand(command, commandList);
        }else if (command.i == 2) {
            cd(1, command.opcion);
            insertCommand(command, commandList);
        }else {
            cd(2, command.opcion);
        }
        return i;
    } //cd

    if (strcmp(command.comando, commands[4]) == 0) { // date
        if (command.i == 1) {
            date(0);
        }else {
            if (strcmp(command.opcion, "-t") == 0) {
                date(1);
            }else {
                if (strcmp(command.opcion, "-d") == 0) {
                    date(2);
                }else {
                    date(3);
                }
            }
        }
        insertCommand(command, commandList);
        return i;
    } //date

    if (strcmp(command.comando, commands[5]) == 0) { // historic
        if (command.i == 1) {
            historic(0, 0, commands, commandList, fileList);
        }else {
            int num;
            if (sscanf(command.opcion, "%d", &num) == 1) {
                if (num >= 0) {
                    historic(1, num, commands, commandList, fileList);
                    insertCommand(command, commandList);
                }else {
                    historic(2, num, commands, commandList, fileList);
                    insertCommand(command, commandList);
                }
            }else {
                historic(3, num, commands, commandList, fileList);
            }
        }
        return i;
    } //historic

    if (strcmp(command.comando, commands[6]) == 0) {
       if (command.i == 1) {
           openf(0, "",fileList);
       }else if (command.i == 3) {
           if(strcmp(command.modo, "cr") == 0) {
               openf(1, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ap") == 0) {
               openf(2, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ex") == 0) {
               openf(3, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ro") == 0) {
               openf(4, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "rw") == 0) {
               openf(5, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "wo") == 0) {
               openf(6, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "tr") == 0) {
               openf(7, command.opcion, fileList);
               insertCommand(command, commandList);
           }else {
               openf(8, "a", fileList);
           }
       }else {
           openf(8, "b", fileList);
       }
        return i;
    } //open

    if (strcmp(command.comando, commands[7]) == 0) {
        if (command.i == 2) {
            int desc;
            sscanf(command.opcion, "%d", &desc);
            closef(desc, fileList);
            insertCommand(command, commandList);
        }else {
            imprimirError(0); //
        }
        return i;
    } //close

    if (strcmp(command.comando, commands[8]) == 0) {
        if (command.i == 2) {
            int desc;
            sscanf(command.opcion, "%d", &desc);
            dupf(desc, fileList);
            insertCommand(command, commandList);
        }else {
            imprimirError(0);
        }
        return i;
    } //dup

    if (strcmp(command.comando, commands[9]) == 0) {
        infosys();
        insertCommand(command, commandList);
        return i;
    } //infosys

    if (strcmp(command.comando, commands[10]) == 0) {
        if (command.i == 1) {
            help(14, commands);
        }else {
            for (int j = 0; j < MAX_COMMANDS; j++) {
                if (strcmp(command.opcion, commands[j]) == 0) {
                    help(j, commands);
                    return i;
                }
            }
            printf("Opción no válida.\n");
        }
        insertCommand(command, commandList);
        return i;
    } //help

    if ((strcmp(command.comando, commands[11]) == 0) || // exit
       (strcmp(command.comando, commands[12]) == 0) || // quit
       (strcmp(command.comando, commands[13]) == 0)) { //bye
        i = 1;
        insertCommand(command, commandList);
        return i;
    }
    imprimirError(0);
    return i;
}

int main() {
    bool terminado = false;
    commandList commandList;
    createEmptyCommandList(&commandList);
    fileList fileList;
    createEmptyFileList(&fileList);

    char *commands[MAX_COMMANDS] = {
        "authors", "pid", "ppid", "cd", "date", "historic", "open", "close",
        "dup", "infosys", "help", "exit", "quit", "bye"
    };

    while (!terminado) {
        imprimirPrompt();
        command command = leerEntrada();

        if (command.i > 0) {
            int i = procesarEntrada(command, commands, &commandList, &fileList);

            if (i == 1) {
                terminado = true;
            }
        }
    }
    freeCommandList(&commandList);
    return 0;
}
