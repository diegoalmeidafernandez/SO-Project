#include "fileList.h"

#include <stdlib.h>

void createEmptyFileList(fileList *fileList) {
    fileList -> firstFile = NULL;
    fileList -> lastFile = NULL;
}

void freeFileList(fileList *fileList) {
    filePos currentFile = fileList -> firstFile;
    filePos nextFile;

    while (currentFile != NULL) {
        nextFile = currentFile->next;
        free(currentFile);
        currentFile = nextFile;
    }
    fileList -> firstFile = NULL;
    fileList -> lastFile = NULL;
}

bool isEmptyFileList (fileList fileList) {
    return (fileList.firstFile == NULL);
}

filePos firstFile (fileList fileList) {
    return fileList.firstFile;
}

filePos lastFile (fileList fileList) {
    return fileList.lastFile;
}

filePos previousFile (filePos pos, fileList fileList) {
    filePos filePos =  firstFile(fileList);

    while (filePos != NULL && nextFile(filePos, fileList) != pos) {
        filePos = nextFile(filePos, fileList);
    }
    return filePos;
}

filePos nextFile (filePos filePos, fileList fileList) {
    return filePos -> next;
}

bool createFileNode (filePos *filePos) {
    *filePos = malloc(sizeof(struct fileNode));
    return (*filePos != NULL);
}

void insertFile (Tfile file, fileList *fileList) {
    filePos pos;

    if (!createFileNode(&pos)) {
        return;
    }

    pos -> file = file;
    pos -> next = NULL;

    if (isEmptyFileList(*fileList)) {
        pos -> num = 1;
        fileList->firstFile = pos;
        fileList->lastFile = pos;
    }else {
        pos -> num = fileList -> lastFile -> num + 1;
        fileList->lastFile -> next = pos;
        fileList->lastFile = pos;
    }
}

filePos searchFile (int des, fileList fileList) {
    if (!isEmptyFileList(fileList)) {
        filePos currentPos = NULL;
        for (currentPos = firstFile(fileList); currentPos != NULL && currentPos -> file.descriptor != des; currentPos = nextFile(currentPos, fileList));
        return currentPos;
    }
    return NULL;
}

void deleteFile (filePos pos, fileList *fileList){ // corregir tabulaciones
    if (pos == firstFile(*fileList)){
        if (firstFile(*fileList) == lastFile(*fileList)) {
            fileList -> firstFile = NULL;
            fileList -> lastFile = NULL;
        }else {
            fileList -> firstFile = nextFile(pos, *fileList);
        }
    }else{
        filePos previousPos = previousFile(pos, *fileList);
        if (pos == lastFile(*fileList)){
            previousPos -> next = nextFile(pos, *fileList);
            fileList -> lastFile = previousPos;
        }else {
            previousPos -> next = nextFile(pos, *fileList);
        }
    }
    free(pos);
}

Tfile getFile (filePos filePos, fileList fileList) {
    return filePos -> file;
}

void printFileList (fileList fileList) {
    if (isEmptyFileList(fileList)) {
        printf("Aún no hay ningún archivo.\n");
    }else {
        for (filePos currentPos = firstFile(fileList); currentPos != NULL; currentPos = nextFile(currentPos, fileList)) {
            Tfile currentFile = getFile(currentPos, fileList);

            printf("FileNum %d:\t%s\n", currentPos -> num, currentFile.filename);
        }
    }
}
