#include "fileList.h"

#include <stdlib.h>

void createEmptyFileList(fileList *fileList) {
    fileList -> firstFile = NULL;
    fileList -> lastFile = NULL;
}

void freeFileList(fileList *fileList) {
    filePos currentFile = fileList -> firstFile;
    filePos nextFile;

    while (currentFile != NULL) {
        nextFile = currentFile->next;
        free(currentFile);
        currentFile = nextFile;
    }
    fileList -> firstFile = NULL;
    fileList -> lastFile = NULL;
}

bool isEmptyFileList (fileList fileList) {
    return (fileList.firstFile == NULL);
}

filePos firstFile (fileList fileList) {
    return fileList.firstFile;
}

filePos lastFile (fileList fileList) {
    return fileList.lastFile;
}

filePos previousFile (filePos pos, fileList fileList) {
    filePos filePos =  firstFile(fileList);

    while (filePos != NULL && nextFile(filePos, fileList) != pos) {
        filePos = nextFile(filePos, fileList);
    }
    return filePos;
}

filePos nextFile (filePos filePos, fileList fileList) {
    return filePos -> next;
}

bool createFileNode (filePos *filePos) {
    *filePos = malloc(sizeof(struct fileNode));
    return (*filePos != NULL);
}

void insertFile (Tfile file, fileList *fileList) {
    filePos pos;

    if (!createFileNode(&pos)) {
        return;
    }

    pos -> file = file;
    pos -> next = NULL;

    if (isEmptyFileList(*fileList)) {
        pos -> num = 1;
        fileList->firstFile = pos;
        fileList->lastFile = pos;
    }else {
        pos -> num = fileList -> lastFile -> num + 1;
        fileList->lastFile -> next = pos;
        fileList->lastFile = pos;
    }
}

filePos searchFile (int num, fileList fileList) {
    if (num < 1 || num > lastFile(fileList) -> num || isEmptyFileList(fileList)) {
        return NULL;
    }

    filePos currentFile = firstFile(fileList);
    while (currentFile != NULL) {
        if (currentFile -> num == num) {
            return currentFile;
        }
        currentFile = nextFile(currentFile, fileList);
    }
    return NULL;
}

Tfile getFile (filePos filePos, fileList fileList) {
    return filePos -> file;
}

void printFileList (fileList fileList) {
    if (isEmptyFileList(fileList)) {
        printf("Aún no hay ningún archivo.\n");
    }else {
        for (filePos currentPos = firstFile(fileList); currentPos != NULL; currentPos = nextFile(currentPos, fileList)) {
            Tfile currentFile = getFile(currentPos, fileList);

            printf("CommNum %d:\t%s\n", currentPos -> num, currentFile.filename);
        }
    }
}
