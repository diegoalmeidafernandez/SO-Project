#ifndef PROCESSLIST_H
#define PROCESSLIST_H
#include "types.h"
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <pwd.h>

typedef struct processNode *processPos;
struct processNode {
    Tprocess process;
    processPos next;
};

typedef struct processList {
    processPos firstProcess;
    processPos lastProcess;
}processList;

void createEmptyProcessList (processList *processList);

void freeProcessList (processList *processList);

bool isEmptyProcessList (processList processList);

processPos firstProcess (processList processList);

processPos lastProcess (processList processList);

processPos previousProcess (processPos processPos, processList processList);

processPos nextProcess (processPos processPos, processList processList);

bool createProcessNode (processPos *processPos);

void insertProcess (Tprocess process, processList *processList);

void deleteProcess (processPos processPos, processList *processList);

void deleteTermSigProcess (bool term, bool sig, processList *processList);

Tprocess getProcess (processPos processPos, processList processList);

processPos searchPidProcess (int pid, processList processList);

char* statusToString (ProcessStatus status);

void formatTime (time_t rawtime, char* buffer, size_t bufferSize);

void getUserName (uid_t uid, char* buffer, size_t bufferSize);

void updateStatusProcess (int pid, ProcessStatus status, processList *processList);

void printProcessList (processList processList);

#endif //PROCESSLIST_H