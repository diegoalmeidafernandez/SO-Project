#ifndef PROCESSLIST_H
#define PROCESSLIST_H
#include "types.h"
#include <stdbool.h>

typedef struct processNode *processPos;
struct processNode {
    Tprocess process;
    processPos next;
};

typedef struct processList {
    processPos firstProcess;
    processPos lastProcess;
}processList;

void createEmptyProcessList (processList *processList);

void freeProcessList (processList *processList);

bool isEmptyProcessList (processList processList);

processPos firstProcess (processList processList);

processPos lastProcess (processList processList);

processPos previousProcess (processPos processPos, processList processList);

processPos nextProcess (processPos processPos, processList processList);

bool createProcessNode (processPos *processPos);

void insertProcess (Tprocess process, processList *processList);

void deleteProcess (processPos processPos, processList *processList);

Tprocess getProcess (processPos processPos, processList processList);

#endif //PROCESSLIST_H