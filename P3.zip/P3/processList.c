#include "processList.h"
#include <stdlib.h>

void createEmptyProcessList (processList *processList) {
    processList ->  firstProcess = NULL;
    processList -> lastProcess = NULL;
}

void freeProcessList (processList *processList) {
    processPos currentProcess = processList -> firstProcess;
    processPos nextProcess;

    while (currentProcess != NULL) {
        nextProcess = currentProcess -> next;
        free(currentProcess);
        currentProcess = nextProcess;
    }
    processList -> firstProcess = NULL;
    processList -> lastProcess = NULL;
}

bool isEmptyProcessList (processList processList) {
    return (processList.firstProcess == NULL);
}

processPos firstProcess (processList processList) {
    return processList.firstProcess;
}

processPos lastProcess (processList processList) {
    return processList.lastProcess;
}

processPos previousProcess (processPos pos, processList processList) {
    processPos processPos = firstProcess(processList);

    while (processPos != NULL && nextProcess(processPos, processList) != NULL) {
        processPos = nextProcess(processPos, processList);
    }
    return processPos;
}

processPos nextProcess (processPos processPos, processList processList) {
    return processPos -> next;
}

bool createProcessNode (processPos *processPos) {
    *processPos = malloc(sizeof(struct processNode));
    return (*processPos != NULL);
}

void insertProcess (Tprocess process, processList *processList) {
    processPos pos;

    if (!createProcessNode(&pos)) {
        return;
    }

    pos -> process = process;
    pos -> next = NULL;

    if (isEmptyProcessList(*processList)) {
        processList -> firstProcess = pos;
        processList -> lastProcess = pos;
    }else {
        processList -> lastProcess -> next = pos;
        processList -> lastProcess = pos;
    }
}

void deleteProcess (processPos pos, processList *processList) {
    if (pos == firstProcess(*processList)) {
        if (firstProcess(*processList) == lastProcess(*processList)) {
            processList -> firstProcess = NULL;
            processList -> lastProcess = NULL;
        }else {
            processList -> firstProcess = nextProcess(pos, *processList);
        }
    }else {
        processPos previousPos = previousProcess(pos, *processList);
        if (pos == lastProcess(*processList)) {
            previousPos -> next = nextProcess(pos, *processList);
            processList -> lastProcess = previousPos;
        }else {
            previousPos -> next = nextProcess(pos, *processList);
        }
    }
    free(pos);
}

Tprocess getProcess (processPos processPos, processList processList) {
    return processPos -> process;
}

processPos searchPidProcess (int pid, processList processList) {
    processPos currentProcess;
    for (currentProcess = firstProcess(processList); currentProcess != NULL; currentProcess = nextProcess(currentProcess, processList)) {
        if (getProcess(currentProcess, processList).pid == pid) {
            return currentProcess;
        }
    }
    return NULL;
}

char* statusToString (ProcessStatus status){
    switch (status) {
        case FINISHED : return "TERMINADO";
        case STOPPED : return "DETENIDO";
        case SIGNALED : return "SEÑALADO";
        case ACTIVE : return "ACTIVO";
        default : return "DESCONOCIDO";
    }
}

void formatTime (time_t rawtime, char* buffer, size_t bufferSize) {
    struct tm *timeinfo = localtime(&rawtime);
    strftime(buffer, bufferSize, "%Y-%m-%d %H:%M:%S", timeinfo);
}

void getUserName (uid_t uid, char* buffer, size_t bufferSize) {
    struct passwd* user = getpwuid(uid);
    if (user) {
        strncpy(buffer, user -> pw_name, bufferSize - 1);
        buffer[bufferSize - 1] = '\0';
    }else {
        strncpy(buffer, "DESCONOCIDO", bufferSize - 1);
        buffer[bufferSize - 1] = '\0';
    }
}

void updateStatusProcess (int pid, ProcessStatus status, processList *processList) {
    processPos foundProcess = searchPidProcess(pid, *processList);
    if (foundProcess != NULL) {
        foundProcess -> process.status = status;
    }else {
        perror("ERROR: No se pudo actualizar el estado del proceso.\n");
    }
}

void printProcessList (processList processList) {
    if (!isEmptyProcessList(processList)) {
        printf("%10s %10s %5s %19s %15s %s\n", "PID", "USER", "PRIO", "TIME", "STATUS", "COMMAND");
        for (processPos currentProcess = firstProcess(processList); currentProcess != NULL; currentProcess = nextProcess(currentProcess, processList)) {
            Tprocess process = getProcess(currentProcess, processList);

            char formattedTime[20];
            formatTime(process.time, formattedTime, sizeof(formattedTime));
            char userName[20];
            getUserName(getuid(), userName, sizeof(userName));

            printf("%10d %10s p=%-3d %19s %15s %s\n", process.pid, userName, process.priority, formattedTime, statusToString(process.status), process.command);
        }
    }
}