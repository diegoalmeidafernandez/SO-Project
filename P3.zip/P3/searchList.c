#include "searchList.h"
#include <stdlib.h>

void createEmptySearchList (searchList *searchList) {
    searchList -> firstSearch = NULL;
    searchList -> lastSearch = NULL;
}

void freeSearchList (searchList *searchList) {
    searchPos currentSearch = searchList -> firstSearch;
    searchPos nextSearch;

    while (currentSearch != NULL) {
        nextSearch = currentSearch -> next;
        free(currentSearch);
        currentSearch = nextSearch;
    }
    searchList -> firstSearch = NULL;
    searchList -> lastSearch = NULL;
}

bool isEmptySearchList (searchList searchList) {
    return (searchList.firstSearch == NULL);
}

searchPos firstSearch (searchList searchList) {
    return searchList.firstSearch;
}

searchPos lastSearch (searchList searchList) {
    return searchList.lastSearch;
}

searchPos previousSearch (searchPos pos, searchList searchList) {
    searchPos searchPos = firstSearch(searchList);

    while (searchPos != NULL && nextSearch(searchPos, searchList) != pos) {
        searchPos = nextSearch(searchPos, searchList);
    }
    return searchPos;
}

searchPos nextSearch (searchPos searchPos, searchList searchList) {
    return searchPos -> next;
}

bool createSearchNode (searchPos *searchPos) {
    *searchPos = malloc(sizeof(struct searchNode));
    return (*searchPos != NULL);
}

void insertSearch (Tsearch search, searchList *searchList) {
    searchPos pos;

    if (!createSearchNode(&pos)) {
        return;
    }

    pos -> search = search;
    pos -> next = NULL;

    if (isEmptySearchList(*searchList)) {
        searchList -> firstSearch = pos;
        searchList -> lastSearch = pos;
    }else {
        searchList -> lastSearch -> next = pos;
        searchList -> lastSearch = pos;
    }
}

void deleteSearch (searchPos pos, searchList *searchList) {
    if (pos == firstSearch(*searchList)) {
        if (firstSearch(*searchList) == lastSearch(*searchList)) {
            searchList -> firstSearch = NULL;
            searchList -> lastSearch = NULL;
        }else {
            searchList -> firstSearch = nextSearch(pos, *searchList);
        }
    }else {
        searchPos previousPos = previousSearch(pos, *searchList);
        if (pos == lastSearch(*searchList)) {
            previousPos -> next = nextSearch(pos, *searchList);
            searchList -> lastSearch = previousPos;
        }else {
            previousPos -> next = nextSearch(pos, *searchList);
        }
    }
    free(pos);
}

Tsearch getSearch (searchPos searchPos, searchList searchList) {
    return searchPos -> search;
}

searchPos searchSearch (char *dir, searchList searchList) {
    if (!isEmptySearchList(searchList)) {
        for (searchPos searchPos = firstSearch(searchList); searchPos != NULL; searchPos = nextSearch(searchPos, searchList)) {
            Tsearch search = getSearch(searchPos, searchList);
            if (strcmp(dir, search.dir) == 0) {
                return searchPos;
            }
        }
    }
    return NULL;
}

void printSearchList (searchList searchList){
    if (!isEmptySearchList(searchList)){
        for (searchPos pos = firstSearch(searchList); pos != NULL; pos = nextSearch(pos, searchList)){
            Tsearch search = getSearch(pos, searchList);
            printf("%s\n", search.dir);
        }
    }
}

char * Ejecutable (char *s, searchList searchList) {
    static char path[MAXDIR];
    struct stat st;

    if (s[0] == '/' || strncmp(s, "./", 2) == 0 || strncmp(s, "../", 3) == 0) {
        return s;
    }

    searchPos pos = firstSearch(searchList);
    while (pos != NULL) {
        snprintf(path, MAXDIR, "%s/%s", getSearch(pos, searchList).dir, s);

        if (lstat(path, &st) == 0 && (st.st_mode & S_IXUSR)) {
            return path;
        }
        pos = nextSearch(pos, searchList);
    }
    return NULL;
}

int Execpve (char *tr[], char **NewEnv, searchList searchList) {
    char *p = Ejecutable(tr[0], searchList);

    if (!p) {
        errno = EFAULT;
        return -1;
    }

    if (!NewEnv) {
        return execv(p, tr);
    }else {
        return execve(p, tr, NewEnv);
    }
}