#ifndef SEARCHLIST_H
#define SEARCHLIST_H
#include "types.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

typedef struct searchNode *searchPos;
struct searchNode {
    Tsearch search;
    searchPos next;
};

typedef struct searchList {
    searchPos firstSearch;
    searchPos lastSearch;
}searchList;

void createEmptySearchList (searchList *searchList);

void freeSearchList (searchList *searchlist);

bool isEmptySearchList (searchList searchList);

searchPos firstSearch (searchList searchList);

searchPos lastSearch (searchList searchList);

searchPos previousSearch (searchPos searchPos, searchList searchList);

searchPos nextSearch (searchPos searchPos, searchList searchList);

bool createSearchNode (searchPos *searchPos);

void insertSearch (Tsearch search, searchList *searchList);

void deleteSearch (searchPos searchPos, searchList *searchList);

Tsearch getSearch (searchPos searchPos, searchList searchList);

searchPos searchSearch (char *path, searchList searchList);

void printSearchList (searchList searchList);

char * Ejecutable  (char *s, searchList searchList);

int Execpve (char *tr[], char **NewEnv, searchList searchList);

#endif //SEARCHLIST_H