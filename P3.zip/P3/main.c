/*
 * Nombres y login: Diego Adrián Almeida Fernández (diego.almeida.fernandez@udc.es) y Juan Melón Domínguez (j.melon@udc.es)
 */

#include <ctype.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/wait.h>

#include "commandList.h"
#include "types.h"
#include "fileList.h"
#include "memoryList.h"
#include "searchList.h"
#include "processList.h"


#define MAX_TROZOS 100
#define MAX_STRING 100
#define MAX_COMMANDS 49
#define NAME0 "Diego Adrián Almeida Fernández"
#define NAME1 "Juan Melón Domínguez"
#define LOGIN0 "diego.almeida.fernandez@udc.es"
#define LOGIN1 "j.melon@udc.es"
#define NO_VALID_COMMAND 0
#define NO_VALID_OPTION 1
#define ERROR (-1)
#define NAMEANDLOGIN 0
#define NAME 1
#define LOGIN 2
#define CWD 0
#define CD 1
#define DATEANDTIME 0
#define TIME 1
#define DATE 2
#define PRINT 0
#define EX 1
#define PRINTN 2
#define NO_MODE 0
#define CR 1
#define AP 2
#define EX0 3
#define RO 4
#define RW 5
#define WO 6
#define TR 7
#define LONG 1
#define ACC 2
#define LINK 3
#define HID 4
#define MALLOC 0
#define MMAP 1
#define CREATE_SHARED 2
#define ATTACH_SHARED 3
#define SHARED 2
#define DELKEY 3
#define ADDR 4
#define PRINTD 5
#define FUNCS 0
#define VARS 1
#define BLOCKS 2
#define ALL 3
#define PMAP 4
#define ENVIRON 1

//FUNCION FMEMORY
int global_inicializada_1 = 1, global_inicializada_2 = 2, global_inicializada_3 = 3;

int global1, global2, global3;

static int estatica_inicializada_1 = 1, estatica_inicializada_2 = 2, estatica_inicializada_3 = 3;

static int estatica1, estatica2, estatica3;

//FUNCION ENVIRON
extern char **environ;

//DECLARACIÓN DE FUNCIONES

void imprimirPrompt();

int TrocearCadena(char *cadena, char *trozos[]);

command leerEntrada();

void imprimirError(int opcion);

void authors(int opcion);

void pid();

void ppid();

void cd(int opcion, char dir[50]);

void openf(int opcion, char *file, fileList *fileList);

void closef(int desc, fileList *fileList);

void dupf(int desc, fileList *fileList);

void date(int opcion);

void historic(int opcion, int num, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList, memoryList *memoryList, char *main_environ[]);

void infosys();

void help(int opcion, char *commands[MAX_COMMANDS]);

void makeFile(char *fileName);

void makeDir(char *dirName);

void permisos(mode_t mode);

void listFile(char *dir, int opcion);

void cwd();

void listDir(char *dir, int opcion);

void recList(char *dir);

void revList(char *dir);

void erase(char *path);

void delRec(char *path);

void allocate (int opcion, int tam, char *fileName, char *permissions, int clave, memoryList *memoryList);

void deallocate (int opcion, int n, char *fileName, void *address, int clave, memoryList *memoryList);

void *cadtop(char *s);

void memfill(char *adrr, int cont, char ch);

void memdump(char *adrr, int cont);

void Do_pmap (void);

void fmemory(int opcion, memoryList *memoryList);

ssize_t Leerfichero(char *file, void *p, size_t cont);

ssize_t LeerFicheroDescriptor(int desc, void *p, size_t cont);

void freadfile(char *file, char *addr, int cont);

void fread0(int desc, char *addr, int cont, fileList *fileList);

ssize_t Escribirfichero(char *file, void *p, size_t cont);

ssize_t EscribirFicheroDescriptor(int desc, void *p, size_t cont);

void fwritefile(char *file, char *addr, int cont);

void fwrite0(int desc, char *addr, int cont, fileList *fileList);

void recurse(int n);

void fgetuid();

void fsetuid(int login, char *new_uid);

void fenviron(int opcion, char **main_environ);

int procesarEntrada(command command, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList, memoryList *memoryList, char *main_environ[]);



/////////////////////////////////////////////////////////////////////////////////////////////

//CODIFICACION DE FUNCIONES

void imprimirPrompt() {
    printf("~$ ");
}

int TrocearCadena(char *cadena, char *trozos[])  {
    int i = 0;

    if ((trozos[i] = strtok(cadena, " \n\t")) == NULL) {
        return 0;
    }
    while ((trozos[++i] = strtok(NULL, " \n\t")) != NULL && i < MAX_TROZOS);
    return i;
}

command leerEntrada() {
    char entrada[MAX_STRING];
    char *trozos[MAX_TROZOS];
    command command;

    fgets(entrada, MAX_STRING, stdin);
    int i = TrocearCadena(entrada, trozos);

    command.i = i;

    switch (i) {
        case 0 :
            strcpy(command.comando, "");
            strcpy(command.opcion, "");
            strcpy(command.modo, "");
            strcpy(command.procedimiento, "");
            break;
        case 1 :
            strcpy(command.comando, trozos[0]);
            strcpy(command.opcion, "");
            strcpy(command.modo, "");
            strcpy(command.procedimiento, "");
            break;
        case 2 :
            strcpy(command.comando, trozos[0]);
            strcpy(command.opcion, trozos[1]);
            strcpy(command.modo, "");
            strcpy(command.procedimiento, "");
            break;
        case 3 :
            strcpy(command.comando, trozos[0]);
            strcpy(command.opcion, trozos[1]);
            strcpy(command.modo, trozos[2]);
            strcpy(command.procedimiento, "");
            break;
        case 4 :
            strcpy(command.comando, trozos[0]);
            strcpy(command.opcion, trozos[1]);
            strcpy(command.modo, trozos[2]);
            strcpy(command.procedimiento, trozos[3]);
            break;
    }
    return command;
}

void imprimirError(int opcion) {
    switch (opcion) {
        case NO_VALID_COMMAND : perror("Comando no válido\n");
            break;
        case NO_VALID_OPTION : perror("Opción no válida\n");
            break;
    }
}

void authors(int opcion) {
    switch (opcion) {
        case NAMEANDLOGIN:
            printf(NAME0 "\t" NAME1 "\n" LOGIN0 "\t" LOGIN1 "\n");
            break;
        case NAME:
            printf(NAME0 "\t" NAME1 "\n");
            break;
        case LOGIN:
            printf(LOGIN0 "\t" LOGIN1 "\n");
            break;
        default:
            imprimirError(NO_VALID_OPTION);
            break;
    }
}

void pid(){
    int pid = getpid();
    printf("%d\n", pid);
}

void ppid(){
    int ppid = getppid();
    printf("%d\n", ppid);
}

void cd(int opcion, char dir[50]){
    switch(opcion) {
        case CWD : cwd();
            break;
        case CD : if (chdir(dir) == 0) {
                    char buffer1[1024];
                    char *currentcd = getcwd(buffer1, sizeof(buffer1));
                    printf("%s\n", currentcd);
                }else {
                    imprimirError(NO_VALID_OPTION);
                }
            break;
        default : imprimirError(NO_VALID_OPTION);
            break;
    }
}

void openf(int opcion, char *file, fileList *fileList) {

    Tfile fichero;
    strcpy(fichero.filename, file);
    char buffer[1024];
    char *path = getcwd(buffer, sizeof(buffer));
    if (path == NULL) {
        perror("Error al obtener el directorio de trabajo actual\n");
        return;
    }
    path = strcat(path, "/");
    char *filepath = strcat(path, file);

       switch (opcion) {
        case NO_MODE: //sin modo
            cd(0, "/proc/self/fd");
            printFileList(*fileList);
            break;
        case CR: //cr
            int descr = open(filepath, O_CREAT | O_WRONLY, 0644);
            if (descr != -1) {
                printf("El archivo %s ha sido creado correctamente en la ruta:\t%s\n", fichero.filename, filepath);
                strcpy(fichero.openningMode, "cr");
                fichero.descriptor = descr;
                insertFile(fichero, fileList);
            }else {
                perror("Error al abrir el archivo\n");
            }
            break;
        case AP: //ap
            if(searchFileName(file, *fileList) != NULL) {
                int descap = open(filepath, O_APPEND | O_WRONLY);
                if (descap != -1) {
                    printf("Archivo abierto en modo append\n");
                    changeOMFile("ap", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al abrir el archivo en modo append\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case EX0: //ex
            if (searchFileName(file, *fileList) == NULL) {
                int decex = open(filepath, O_CREAT | O_EXCL | O_WRONLY, 0644);
                if (decex != -1) {
                    printf("El archivo %s ha sido creado correctamente en la ruta:\t%s\n", fichero.filename, filepath);
                    strcpy(fichero.openningMode, "ex");
                    fichero.descriptor = decex;
                    insertFile(fichero, fileList);
                }else {
                    perror("Error al crear el archivo\n");
                }
            }else {
                perror("El archivo ya existe\n");
            }
            break;
        case RO: //ro
            if (searchFileName(file, *fileList) != NULL) {
                int descro = open(filepath, O_RDONLY);
                if (descro != -1) {
                    changeOMFile("ro", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al abrir el archivo en modo lectura\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case RW: //rw
            if (searchFileName(file, *fileList) != NULL) {
                int descrw = open(filepath, O_RDWR);
                if (descrw != -1) {
                    changeOMFile("rw", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al abrir el archivo en modo lectura/escritura\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        case WO: //wo
            if (searchFileName(file, *fileList) != NULL) {
                int descwo = open(filepath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if (descwo != -1) {
                    printf("Archivo abierto en modo escritura, contenido truncado\n");
                    strcpy(fichero.openningMode, "wo");
                    fichero.descriptor = descwo;
                    insertFile(fichero, fileList);
                }else {
                    perror("Error al abrir el archivo en modo escritura\n");
                }
            }else {
                perror("EL archivo no existe\n");
            }
            break;
        case TR: //tr
            if (searchFileName(file, *fileList) != NULL) {
                int desctr = open(filepath, O_TRUNC | O_WRONLY);
                if (desctr != -1) {
                    printf("El contenido del archivo ha sido borrado\n");
                    changeOMFile("tr", searchFileName(file, *fileList), fileList);
                }else {
                    perror("Error al truncar el archivo\n");
                }
            }else {
                perror("El archivo no existe\n");
            }
            break;
        default:
            if (strcmp(file, "a") == 0) {
                imprimirError(NO_VALID_OPTION);
            }else {
                imprimirError(NO_VALID_COMMAND);
            }
    }
}

void closef(int desc, fileList *fileList) {
   filePos filePos = searchFileNum(desc, *fileList);
    if (filePos == NULL){
        perror("No se puede acceder al archivo\n");
    }else {
        deleteFile(filePos, fileList);
        printf("El archivo se ha cerrado correctamente\n");
    }
}

void dupf(int desc, fileList *fileList) {
    filePos filePos = searchFileNum(desc, *fileList);
    if (filePos == NULL) {
        perror("No se puede acceder al archivo\n");
    }else {
        insertFile(getFile(filePos, *fileList), fileList);
        printf("El archivo se ha duplicado correctamente\n");
    }
}

void date(int opcion) {
    time_t t = time(NULL);
    struct tm *tm_info = localtime(&t);

    char buffer[80];

    switch (opcion) {
        case DATEANDTIME:
            strftime(buffer, sizeof(buffer), "Fecha:\t%d/%m/%Y\nHora:\t%H:%M:%S", tm_info);
        printf("%s\n", buffer);
        break;
        case TIME:
            strftime(buffer, sizeof(buffer), "%H:%M:%S", tm_info);
        printf("Hora:\t%s\n", buffer);
        break;
        case DATE:
            strftime(buffer, sizeof(buffer), "%d/%m/%Y", tm_info);
        printf("Fecha:\t%s\n", buffer);
        break;
        default:
            imprimirError(NO_VALID_OPTION);
        break;
    }
}

void historic(int opcion, int num, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList, memoryList *memoryList, char *main_environ[]) {
    switch (opcion) {
        case 0: printCommandList(*commandList);
            break;
        case 1: commandPos pos = searchCommand(num, *commandList);
                if (pos != NULL) {
                    command command = getCommand(pos, *commandList);
                    procesarEntrada(command, commands, commandList, fileList, memoryList, main_environ);
                }
            break;
        case 2:
                printLastNCommands(num, *commandList);
            break;
        default: imprimirError(NO_VALID_OPTION);
            break;
    }
}

void infosys() {
    struct utsname buffer;

    if (uname(&buffer) != 0) {
        perror("uname");
        return;
    }

    printf("Sistema operativo: %s\n", buffer.sysname);
    printf("Nombre del nodo:   %s\n", buffer.nodename);
    printf("Versión del kernel:%s\n", buffer.release);
    printf("Versión del SO:    %s\n", buffer.version);
    printf("Arquitectura:      %s\n", buffer.machine);
}

void help(int opcion, char *commands[MAX_COMMANDS]) {
    switch (opcion) {
        case 0: //authors
            printf(
                "%s:\tImprime los nombres y logins de los autores del programa.\n%s -l:\tImprime solamente los logins.\n%s -n:\tImprime solamente los nombres.\n",
                commands[0], commands[0], commands[0]);
        break;
        case 1://pid
            printf("%s:\tImprime el PID del proceso ejecutandose en la shell.\n", commands[1]);
        break;
        case 2://ppid
            printf("%s:\tImprime el PID del proceso padre de la shell.\n", commands[2]);
        break;
        case 3://cd
            printf("%s [dir]:\tCambia el directorio actual de trabajo de la shell al deseado.\n", commands[3]);
        break;
        case 4://date
            printf(
                "%s:\tImprime la fecha actual en formato DD/MM/YYYY y la hora actual en formato hh:mm:ss.\n%s -d:\tImprime la fecha actual en formato DD/MM/YYYY.\n%s -t:\tImprime la hora actual en formato hh:mm:ss.\n",
                commands[4], commands[4], commands[4]);
        break;
        case 5://historic
            printf(
                "%s:\tImprime todos los comandos que se han introducido con su número de orden.\n%s N:\tRepite el comando número N.\n%s -N:\tImprime solamente los últimos N-comandos.\n",
                commands[5], commands[5], commands[5]);
        break;
        case 6://open
            printf("%s [file] mode:\tAbre un archivo y lo añade.\n", commands[6]);
        break;
        case 7://close
            printf("%s [df]:\tCierra el descriptor de archivo df y elimina el elemento correspondiente de la lista.\n", commands[7]);
        break;
        case 8://dup
            printf("%s [df]:\tDuplica el descriptor de archivo.\n", commands[8]);
        break;
        case 9://infosys
            printf("%s:\tImprime la información de la máquina que está ejecutando la shell.\n", commands[9]);
        break;
        case 10://help
            printf("%s:\t Muestra por pantalla una lista de los comandos disponibles.\n%s [cmd]:\tBrinda una pequeña descripción del uso de cada comando.\n", commands[10], commands[10]);
        break;
        case 11://exit
            printf("%s:\tCierra el terminal.\n", commands[11]);
        break;
        case 12://quit
            printf("%s:\tCierra el terminal.\n", commands[12]);
        break;
        case 13://bye
            printf("%s:\tCierra el terminal.\n", commands[13]);
        break;
        case 14://makefile
            printf("%s:\tCrea un fichero.\n", commands[14]);
        break;
        case 15://makedir
            printf("%s:\tCrea un directorio.\n", commands[15]);
        break;
        case 16://listfile
            printf("%s:\tDevuelve información de archivos o de directorios.\n", commands[16]);
            printf("%s -long:\tListado largo\n", commands[16]);
            printf("%s -acc:\tMuestra también la hora del último acceso\n", commands[16]);
            printf("%s -link:\tMuestra también el número de enlaces simbólicos\n", commands[16]);
        break;
        case 17://cwd
            printf("%s:\tImprime el directorio actual de trabajo.\n", commands[17]);
        break;
        case 18://listdir
            printf("%s:\tLista el contenido de los directorios.\n", commands[18]);
            printf("%s -long:\tListado largo\n", commands[18]);
            printf("%s -acc:\tMuestra también la hora del último acceso\n", commands[18]);
            printf("%s -link:\tMuestra también el número de enlaces simbólicos\n", commands[18]);
            printf("%s -hid:\tMuestra también los direcctorios ocultos\n", commands[18]);
        break;
        case 19://reclist
            printf("%s:\tLista directorios de forma recursiva (subdirectorios después).\n", commands[19]);
        break;
        case 20://revlist
            printf("%s:\tLista directorios de forma recursiva (subdirectorios antes).\n", commands[20]);
        break;
        case 21://erase
            printf("%s:\tElimina archivos y/o directorios vacíos.\n",commands[21]);
        break;
        case 22://delrec
            printf("%s:\tElimina archivos y/o directorios vacíos de forma recursiva.\n",commands[22]);
        break;
        case 23://allocate
            printf("%s -malloc:\tAsigna un bloque de n bytes de memoria.\n%s -mmap: \tMapea un archivo en memoria con los permisos perm.\n"
                   "%s -createshared:\tCrea un bloque de memoria compartida con clave cl y tamaño n.\n"
                   "%s -shared:\tAdjunta un bloque de memoria compartida al espacio de direcciones (El bloque debe esar creado previamente).\n", commands[23], commands[23], commands[23], commands[230]);
        break;
        case 24://deallocate
            printf("%s -malloc:\tDesasigna un bloque de memoria asignado con malloc de tamaño n (siempre que haya sido previamente asignado con allocate).\n"
                   "%s -mmap:\tDesmapea un archivo de la memoria (siempre que haya sido previamente mapeado).\n"
                   "%s -shared:\tDesadjunta un bloque de memoria compartida con clave cl (siempre que haya sido previamente asignado).\n"
                   "%s -delkey:\tElimina el bloque de memoria con clave cl del sistema.\n"
                   "%s addr:\tDesasigna el bloque en la dirección addr.\n", commands[24], commands[24], commands[24], commands[24], commands[24]);
        break;
        case 25://memfill
            printf("%s addr cont ch:\t Llena la memoria con el caracter ch empezando en addr y durante cont bytes.\n", commands[25]);
        break;
        case 26://memdump
            printf("%s addr cont:\tMuestra el contenido de los cont bytes de memoria a partir de la posición addr.\n", commands[26]);
        break;
        case 27://memory
            printf("%s -funcs:\tImrpime las direcciones de memoria de tres funciones del programa y tres de librería.\n"
                   "%s -vars:\tImprime las direcciones de memoria de: 3 variables externas, 3 variables externas inicializadas, 3 variables estáticas, 3 variables estáticas inicializadas y 3 variables automáticas.\n"
                   "%s -blocks:\tImprime la lista de bloques de memoria asignaddos en el programa.\n"
                   "%s -all:\tImprime toda la información anterior (-funcs, -vars y -blocks).\n"
                   "%s -pmap:\tMuestra un mapa de memoria detallado del proceso.\n", commands[27], commands[27], commands[27], commands[27]);
        break;
        case 28://readfile
            printf("%s file addr cont:\tLee cont bytes de un fichero en la direccion de memoria addr.\n", commands[28]);
        break;
        case 29://writefile
            printf("%s file addr cont:\tEscribe en un archivo file una cantidad de cont bytes empezando en la dirección de memoria addr.\n", commands[29]);
        break;
        case 30://read
            printf("%s df addr cont:\tHace lo mismo que readfile pero usando un descriptor de archivo df ya abierto.\n", commands[30]);
        break;
        case 31://write
            printf("%s df addr cont:\tHace lo mismo que writefile pero usando un descriptor de archivo df ya abierto.\n", commands[31]);
        break;
        case 32://recurse
            printf("%s :\tEjecuta la función recursiva n veces.\n", commands[32]);
        break;
        case 33://getuid
            printf("%s :\tMuestra las credenciales del proceso que ejecuta el shell.\n", commands[33]);
        break;
        case 34://setuid
            printf("%s [-l] id:\tCambia las credenciales del proceso que ejecuta el shell.\n"
                "\t\tid: establece la credencial al valor numerico id.\n"
                "\t\t-l id: establece la credencial a login id\n", commands[34]);
        break;
        case 35://showvar
            printf("%s var:\tMuestra el valor y las direcciones de la variable de entorno var.\n", commands[35]);
        break;
        case 36://changevar
            printf("%s [-a|-e|-p] var valor:\tCambia el valor de una variable de entorno"
                "\t\t-a: accede por el tercer arg de main\n"
                "\t\t-e: accede mediante environ\n"
                "\t\t-p: accede mediante putenv\n", commands[36]);
        break;
        case 37://subsvar
            printf("%s [-a|-e] var1 var2 valor:\tSustituye la variable de entorno var1 con var2 = valor.\n"
            "\t\t-a: accede por el tercer arg de main\n"
            "\t\t-e: accede mediante environ\n", commands[37]);
        break;
        case 38://environ
            printf("%s [-environ|-addr]:\tMuestra el entorno del proceso.\n"
            "\t\t-environ: accede usando environ (en lugar del tercer arg de main)\n"
            "\t\t-addr: muestra el valor y donde se almacenan environ y el 3er arg main\n", commands[38]);
        break;
        case 39://fork
            printf("%s :\tEl shell hace fork y queda en espera a que su hijo termine.\n", commands[39]);
        break;
        case 40://search
            printf("%s [-add|-del|-clear|-path]:\tManipula o muestra la ruta de busqueda del shell (path).\n"
            "\t\t-add dir: aniade dir a la ruta de busqueda(equiv +dir)\n"
            "\t\t-del dir: elimina dir de la ruta de busqueda (equiv -dir)\n"
            "\t\t-clear: vacia la ruta de busqueda\n"
            "\t\t-path: importa el PATH en la ruta de busqueda\n", commands[40]);
        break;
        case 41://exec
            printf("%s VAR1 VAR2 ..prog args....[@pri]:\tEjecuta, sin crear proceso,prog con argumentos en un entorno que contiene solo las variables VAR1, VAR2...", commands[41]);
        break;
        case 42://execpri
            printf("%s prio prog args:\tEjecuta, sin crear proceso, prog con argumentos con la prioridad cambiada a prio.\n", commands[42]);
        break;
        case 43://fg
            printf("%s prog args:\tCrea un proceso que ejecuta en primer plano prog con argumentos.\n", commands[43]);
        break;
        case 44://fgpri
            printf("%s prio prog args:\tCrea un proceso que ejecuta en primer plano prog con argumentos con la prioridad cambiada a prio.\n", commands[44]);
        break;
        case 45://back
            printf("%s prog args:\tCrea un proceso que ejecuta en segundo plano prog con argumentos.\n", commands[45]);
        break;
        case 46://backpri
            printf("%s prio prog args:\tCrea un proceso que ejecuta en segundo plano prog con argumentos con la prioridad cambiada a prio.\n", commands[46]);
        break;
        case 47://listjobs
            printf("%s :\tLista los procesos en segundo plano.\n", commands[47]);
        break;
        case 48://deljobs
            printf("%s [-term][-sig]:\tElimina los procesos de la lista procesos en sp.\n"
            "\t\t-term: los terminados\n"
            "\t\t-sig: los terminados por senal\n", commands[48]);
        break;
        case 49:
            printf("Comandos disponibles:\n");
            for (int i = 0; i < MAX_COMMANDS; i++){
                printf("%s\n", commands[i]);
            }
        break;
        default:
            imprimirError(NO_VALID_OPTION);
        break;
    }
}

void makeFile(char *fileName) {
    char buffer[1024];
    char *path = getcwd(buffer, sizeof(buffer));

    if (path == NULL) {
        perror("No se ha podido obtener el directorio actual de trabajo.\n");
    }else {
        path = strcat(path, "/");
        char *filepath = strcat(path, fileName);

        int descr = open(filepath, O_CREAT | O_WRONLY, 0644);
        if (descr != -1) {
            printf("El archivo %s se ha creado correctamente en la ruta %s\n", fileName, filepath);
        }else {
            perror("Error al crear el archivo.\n");
        }
    }
}

void makeDir(char *dirName) {
    char buffer[1024];
    char *path = getcwd(buffer, sizeof(buffer));

    if (path == NULL) {
        perror("No se ha podido obtener el directorio actual de trabajo.\n");
    }else {
        path = strcat(path, "/");
        char *dirpath = strcat(path, dirName);

        int dir = mkdir(dirName, 0755);
        if (dir == 0) {
            printf("El directorio %s se ha creado correctamente en la ruta %s\n", dirName, dirpath);
        }else {
            perror("Error al crear el directorio.\n");
        }
    }
}

void permisos(mode_t mode) {
    char permisos[11] = "-----------";

    // Tipo de archivo
    if (S_ISDIR(mode)) {
        permisos[0] = 'd';
    } else if (S_ISLNK(mode)) {
        permisos[0] = 'l';
    } else {
        permisos[0] = '-';
    }

    if (mode & S_IRUSR) permisos[1] = 'r';
    if (mode & S_IWUSR) permisos[2] = 'w';
    if (mode & S_IXUSR) permisos[3] = 'x';

    if (mode & S_IRGRP) permisos[4] = 'r';
    if (mode & S_IWGRP) permisos[5] = 'w';
    if (mode & S_IXGRP) permisos[6] = 'x';

    if (mode & S_IROTH) permisos[7] = 'r';
    if (mode & S_IWOTH) permisos[8] = 'w';
    if (mode & S_IXOTH) permisos[9] = 'x';

    printf("%s", permisos);
}

void listFile(char *dir, int opcion) {
    struct stat info;

    if (stat(dir, &info) == 0) {

        struct tm *timemod = localtime(&info.st_mtime);
        char fechamod[20];
        strftime(fechamod, sizeof(fechamod), "%Y/%m/%d-%H:%M", timemod);
        struct tm *timeacc = localtime(&info.st_atime);
        char fechaacc[20];
        strftime(fechaacc, sizeof(fechaacc), "%Y/%m/%d-%H:%M", timeacc);
        struct passwd *usuario = getpwuid(info.st_uid);
        char *name = usuario->pw_name;
        struct group *grupo = getgrgid(info.st_gid);
        char *group = grupo->gr_name;

        switch (opcion) {
            case NO_MODE:
                printf("%8ld \t %s\n", info.st_size, dir);
            break;
            case LONG://-long
                printf("%s%8ld\t( %ld )\t%s\t%s\t",fechamod,info.st_nlink, info.st_ino, name , group);
                permisos(info.st_mode);
                printf("\t%ld\t%s\n", info.st_size, dir);
            break;
            case ACC://-acc
                printf("%ld\t%s\t%s\n", info.st_size, fechaacc, dir);
                break;
            case LINK://-link
                printf("%8ld\t%ld\t%s\n", info.st_nlink, info.st_size, dir);
                break;
        }
    }else {
        perror("Error al obtener información del archivo/directorio.\n");
    }
}

void cwd() {
    char buffer[1024];
    char *cwd = getcwd(buffer, sizeof(buffer));

    if (cwd == NULL) {
        perror("Error obteniendo el directorio actual.\n");
    }else {
        printf("%s\n", cwd);
    }
}

void listDir(char *dir, int opcion) {
    struct dirent *entry;
    DIR *d = opendir(dir);

    if (d != NULL) {
        printf("************%s\n", dir);
        for(entry = readdir(d); entry != NULL; entry = readdir(d)) {
            char path[1024];
            struct stat info;

            if (opcion == 4 || strcmp(entry -> d_name, ".") != 0 && strcmp(entry -> d_name, "..") != 0) {
                snprintf(path, sizeof(path), "%s/%s", dir, entry -> d_name);

                if (stat(path, &info) == 0) {
                    switch (opcion) {
                        case LONG:// -long
                            struct tm *timemod = localtime(&info.st_mtime);
                            char fechamod[20];
                            strftime(fechamod, sizeof(fechamod), "%Y/%m/%d-%H:%M", timemod);
                            struct passwd *usuario = getpwuid(info.st_uid);
                            char *name = usuario->pw_name;
                            struct group *grupo = getgrgid(info.st_gid);
                            char *group = grupo->gr_name;

                            printf("%s%8ld\t( %ld )\t%s\t%s\t",fechamod,info.st_nlink, info.st_ino, name , group);
                            permisos(info.st_mode);
                            printf("\t%ld\t%s\n", info.st_size, entry -> d_name);

                            break;
                        case ACC:// -acc
                            struct tm *timeacc = localtime(&info.st_atime);
                            char fechaacc[20];
                            strftime(fechaacc, sizeof(fechaacc), "%Y/%m/%d-%H:%M", timeacc);

                            printf("%ld\t%s\t%s\n", info.st_size, fechaacc, entry -> d_name);

                            break;
                        case LINK:// -link
                            printf("%8ld\t%ld\t%s\n", info.st_nlink, info.st_size, entry -> d_name);
                            break;
                        default:
                            printf("%8ld \t %s\n", info.st_size, entry -> d_name);

                    }
                }else {
                    printf("Error obteniendo información del archivo.\n");
                }
            }
        }
    }else {
        perror("Error obteniendo el directorio.\n");
    }
    closedir(d);
}

void recList(char *dir) {
    struct dirent *entry;
    DIR *d = opendir(dir);

    if (d != NULL) {
        printf("************%s\n", dir);

        for (entry = readdir(d); entry != NULL; entry = readdir(d)) {
            char path[1024];
            struct stat info;

            if (strcmp(entry -> d_name, ".") != 0 && strcmp(entry -> d_name, "..") != 0) {
                snprintf(path, sizeof(path), "%s/%s", dir, entry -> d_name);

                if (stat(path, &info) == 0) {
                    printf("%8ld \t %s\n", info.st_size, entry -> d_name);
                }
            }
        }
    }else {
        perror("Error obteniendo el directorio.\n");
    }

    rewinddir(d);

    for (entry = readdir(d); entry != NULL; entry = readdir(d)) {
        char path[1024];
        struct stat info;

        if (strcmp(entry -> d_name, ".") != 0 && strcmp(entry -> d_name, "..") != 0) {
            snprintf(path, sizeof(path), "%s/%s", dir, entry -> d_name);

            if (stat(path, &info) == 0) {
                if (S_ISDIR(info.st_mode)) {
                    recList(path);
                }
            }else {
                perror ("Error obteniendo el directorio\n");
            }
        }
    }
}

void revList(char *dir) {
    struct dirent *entry;
    DIR *d = opendir(dir);

    if (d != NULL) {
        for (entry = readdir(d); entry != NULL; entry = readdir(d)) {
            char path[1024];
            snprintf(path, sizeof(path), "%s/%s", dir, entry->d_name);
            struct stat info;

            if (stat(path, &info) == 0 && S_ISDIR(info.st_mode)) {
                if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                    revList(path);
                }
            }
        }
        closedir(d);

        d = opendir(dir);
        if (d != NULL) {
            printf("************%s\n", dir);
            for (entry = readdir(d); entry != NULL; entry = readdir(d)) {
                char path[1024];
                struct stat info;

                if (strcmp(entry -> d_name, ".") != 0 && strcmp(entry -> d_name, "..") != 0) {
                    snprintf(path, sizeof(path), "%s/%s", dir, entry -> d_name);

                    if (stat(path, &info) == 0) {
                        printf("%8ld \t %s\n", info.st_size, entry -> d_name);
                    }
                }
            }
        }else {
            perror("Error obteniendo el directorio.\n");
        }
    } else {
        perror("Error obteniendo el directorio.");
    }
}

void erase(char *path) {
    struct stat info;

    if (stat(path, &info) == 0) {
        if (S_ISREG(info.st_mode)) {
            if (remove(path) == 0) {
                printf("Archivo eliminado: %s\n", path);

            }else {
                perror("Error al eliminar el archivo.\n");
            }
        }else {
            if (S_ISDIR(info.st_mode)) {
                DIR *d = opendir(path);
                if (d != NULL) {
                    struct dirent *entry;
                    bool isEmpty = true;

                    for (entry = readdir(d); entry != NULL; entry = readdir(d)) {
                        if (strcmp(entry -> d_name, ".") != 0 && strcmp(entry -> d_name, "..") != 0) {
                            isEmpty = false;
                        }
                    }
                    closedir(d);

                    if (isEmpty) {
                        if (rmdir(path) == 0) {
                            printf("Directorio eliminado: %s\n", path);
                        }else {
                            perror("Error eliminar el archivo.\n");
                        }
                    }else {
                        printf("El directorio no está vacío: %s\n", path);
                    }
                }else {
                    perror("No se pudo abrir el directorio.\n");
                }
            }
        }
    }else {
        perror("Error al obtener información del archivo/directorio.\n");
    }
}

void delRec(char *path) {
    struct stat info;

    if (stat(path, &info) == 0) {
        if (S_ISDIR(info.st_mode)) {
            DIR *d = opendir(path);
            if (d != NULL) {
                struct dirent *entry;

                for (entry = readdir(d); entry != NULL; entry = readdir(d)) {
                    if (strcmp(entry -> d_name, ".") != 0 && strcmp(entry -> d_name, "..") != 0) {
                        char subpath[1024];
                        snprintf(subpath, sizeof(subpath), "%s/%s", path, entry -> d_name);
                        delRec(subpath);
                    }
                }
                closedir(d);
            }
        }
        erase(path);
    }else {
        perror("Error al obtener información del archivo/directorio.\n");
    }
}

int parse_permissions(const char *permisos) {
    int flags = 0;

    if (strstr(permisos, "O_RDONLY")) {
        flags |= O_RDONLY;
    }
    if (strstr(permisos, "O_WRONLY")) {
        flags |= O_WRONLY;
    }
    if (strstr(permisos, "O_RDWR")) {
        flags |= O_RDWR;
    }
    if (strstr(permisos, "O_CREAT")) {
        flags |= O_CREAT;
    }
    if (strstr(permisos, "O_TRUNC")) {
        flags |= O_TRUNC;
    }
    if (strstr(permisos, "O_APPEND")) {
        flags |= O_APPEND;
    }
    if (strstr(permisos, "O_EXCL")) {
        flags |= O_EXCL;
    }
    if (strstr(permisos, "O_NONBLOCK")) {
        flags |= O_NONBLOCK;
    }
    return flags;
}

void allocate (int opcion, int tam, char *fileName, char *permissions, int clave, memoryList *memoryList) {
    void *block = NULL;
    int fd, shm_id;
    int flags = 0;
    struct stat file_stat;
    TMemory memory;
    time_t now;
    struct tm *timeinfo;
    time(&now);
    timeinfo = localtime(&now);
    strftime(memory.timestamp, sizeof(memory.timestamp), "%d %b %y %H:%M", timeinfo);

    switch (opcion) {
        case MALLOC:
            block = malloc(tam);
            if (block != NULL) {
                memory.adress = block;
                memory.size = tam;
                memory.clave = 0;
                memory.decr = 0;
                strcpy(memory.fileName, "");
                strcpy(memory.permissions, "");
                strcpy(memory.type, "malloc");
                insertMemory(memory, memoryList);


                printf("Asignados %d bytes en %p\n", tam, memory.adress);
            }else {
                perror("ERROR: No se pudo reservar memoria.\n");
            }
            break;

        case MMAP:
            flags = parse_permissions(permissions);
            fd = open(fileName, flags);
            if (fd != -1) {
               if (fstat(fd, &file_stat) != -1) {
                   if (file_stat.st_size > 0) {
                       block = mmap(NULL, file_stat.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
                       close(fd);

                       if (block != MAP_FAILED) {
                           memory.adress = block;
                           memory.size = (int)file_stat.st_size;
                           memory.clave = 0;
                           memory.decr = fd;
                           strcpy(memory.fileName, fileName);
                           strcpy(memory.permissions, permissions);
                           strcpy(memory.type, "mapped");
                           insertMemory(memory, memoryList);

                           printf("fichero %s mapeado en %p\n", fileName, block);
                       }else {
                           perror("ERROR: No se pudo mapear el archivo en la memoria.\n");
                       }
                   }else {
                       perror("ERROR: El archivo está vacío.\n");
                   }
               }else {
                   perror("ERROR: No se pudo obtener el tamaño del archivo.\n");
                   close(fd);
               }
            }else {
                perror("ERROR: No se pudo mapear el archivo en la memoria.\n");
            }
            break;

        case CREATE_SHARED:
            shm_id = shmget((key_t) clave, tam, IPC_CREAT | 0666);

            if (shm_id != -1) {
                block = shmat(shm_id, NULL, 0);

                if (block != (void *) -1) {
                    memory.adress = block;
                    memory.size = tam;
                    memory.clave = clave;
                    memory.decr = 0;
                    strcpy(memory.fileName, "");
                    strcpy(memory.permissions, "");
                    strcpy(memory.type, "shared");
                    insertMemory(memory, memoryList);

                    printf("Memoria compartida de clave %d en %p\n", clave, block);
                }else {
                    perror("ERROR: No se pudo crear un bloque de memoria compartida.\n");
                }
            }else {
                perror("ERROR: No se pudo crear un bloque de memoria compartida.\n");
            }
            break;

        case ATTACH_SHARED:
            memoryPos memoryPos = searchMemoryKey(clave, *memoryList);
            if (memoryPos != NULL) {
                shm_id = shmget((key_t) clave, 0, 0666);

                if (shm_id != -1) {
                    block = shmat(shm_id, NULL, 0);

                    if (block != (void *) -1) {
                        memory.adress = block;
                        memory.size = tam;
                        memory.clave = clave;
                        memory.decr = 0;
                        strcpy(memory.fileName, "");
                        strcpy(memory.permissions, "");
                        strcpy(memory.type, "shared");
                        insertMemory(memory, memoryList);

                        printf("Memoria comparida de clave %d en %p\n", clave, block);
                    }else {
                        perror("ERROR: No se pudo acceder al bloque de memoria compartida.\n");
                    }
                }else {
                    perror("ERROR: No se pudo acceder al bloque de memoria compartida.\n");
                }
            }else {
                perror("ERROR: El bloque de memoria compartida no ha sido creado todavía.\n");
            }
            break;

        case PRINTD:
            printMemoryList(getpid(), *memoryList);
            break;
    }
}

void deallocate (int opcion, int n, char *fileName, void *address, int clave, memoryList *memoryList) {
    void *block = NULL;
    memoryPos memoryPos;

    switch (opcion) {
        case MALLOC:
            memoryPos = searchMemoryMalloc(n, *memoryList);

            if (memoryPos != NULL) {
                block = getMemory(memoryPos, *memoryList).adress;
                printf("Desasignados %d bytes en %p\n", n, block);
                free(block);
                deleteMemory(memoryPos, memoryList);
            }else {
                perror("ERROR: No hay bloque de ese tamaño asignado con malloc.\n");
            }
            break;

        case MMAP:
            memoryPos = searchMemoryMapped(fileName, *memoryList);

            if (memoryPos != NULL) {
                block = getMemory(memoryPos, *memoryList).adress;

                if (munmap(block, memoryPos -> memory.size) != -1) {
                    deleteMemory(memoryPos, memoryList);
                    printf("Desmapeado el fichero %s en %p\n", fileName, block);
                }else {
                    perror("ERROR: No se pudo desmapear el archivo.\n");
                }
            }else {
                perror("ERROR: El archivo no se ha mapeado aún.\n");
            }
            break;

        case SHARED:
            memoryPos = searchMemoryKey(clave, *memoryList);

            if (memoryPos != NULL) {
                block = getMemory(memoryPos, *memoryList).adress;

                if (shmdt(block) != -1) {
                    deleteMemory(memoryPos, memoryList);
                    printf("El bloque de memoria compartido en %p con clave %d ha sido desadjuntado.\n", block, clave);
                }else {
                    perror("ERROR: No se pudo desadjuntar el bloque de memoria compartida.\n");
                }
            }else {
                perror("ERROR: No hay bloque de esa clave mapeado en el proceso.\n");
            }
            break;

        case DELKEY:
            if (shmctl(clave, IPC_RMID, NULL) != -1) {
                printf("La clave de memoria %d fue eliminada correctamente del sistema.\n", clave);
            }else {
                perror("ERROR: No se pudo eliminar la clave del bloque de memoria compartida.\n");
            }
            break;

        case ADDR:
            memoryPos = searchMemoryAddress(address, *memoryList);

            if (memoryPos != NULL) {
                if (strcmp(memoryPos -> memory.type, "malloc") == 0) {
                    int size = memoryPos -> memory.size;
                    deallocate(MALLOC, size, "", "", 0, memoryList);
                }else {
                    if (strcmp(memoryPos -> memory.type, "mmap") == 0) {
                        char *fileNameBlock = memoryPos -> memory.fileName;
                        deallocate(MMAP, 0, fileNameBlock, "", 0, memoryList);
                    }else {
                        if (strcmp(memoryPos -> memory.type, "shared") == 0) {
                            int claveBlock = memoryPos -> memory.clave;
                            deallocate(SHARED, 0, "", "", claveBlock, memoryList);
                        }
                    }
                }
            }else {
                perror("ERROR: La direccion de memoria no corresponde con ningun bloque.\n");
            }
            break;

        case PRINTD:
            printMemoryList(getpid(), *memoryList);
            break;
    }
}

void *cadtop(char *s){
    void *p;
    sscanf(s, "%p", &p);
    return p;
}

void memfill(char *adrr, int cont, char ch) {
    void *p = cadtop(adrr);
    unsigned char *arr = (unsigned char *) p;

    printf("Llenando %d bytes de memoria con el byte %c a partir de la direccion %p\n", cont, ch, arr);

    for (int i = 0; i < cont; i++) {
        arr[i] = ch;
    }
}

void memdump(char *adrr, int cont) {
    void *p = cadtop(adrr);
    size_t i;

    if (p != NULL) {
        for (i = 0; i < cont; i++) {
            printf("%02X", ((unsigned char *) p)[i]);

            if (isprint(((unsigned char *) p)[i])) {
                printf("%c", ((unsigned char *) p)[i]);
            } else {
                printf(".");
            }

            if ((i + 1) % 16 == 0) {
                printf("\n");
            }
        }

        if (cont % 16 != 0) {
            printf("\n");
        }
    } else {
        perror("Dirección de memoria inválida.\n");
    }
}

void Do_pmap (void){ pid_t pid;
    char elpid[32];
    char *argv[4]={"pmap",elpid,NULL};

    sprintf (elpid,"%d", (int) getpid());
    if ((pid=fork())==-1){
        perror ("Imposible crear proceso");
        return;
    }
    if (pid==0){
        if (execvp(argv[0],argv)==-1)
            perror("cannot execute pmap (linux, solaris)");

        argv[0]="procstat"; argv[1]="vm"; argv[2]=elpid; argv[3]=NULL;
        if (execvp(argv[0],argv)==-1)/*No hay pmap, probamos procstat FreeBSD */
            perror("cannot execute procstat (FreeBSD)");

        argv[0]="procmap",argv[1]=elpid;argv[2]=NULL;
        if (execvp(argv[0],argv)==-1)  /*probamos procmap OpenBSD*/
            perror("cannot execute procmap (OpenBSD)");

        argv[0]="vmmap"; argv[1]="-interleave"; argv[2]=elpid;argv[3]=NULL;
        if (execvp(argv[0],argv)==-1) /*probamos vmmap Mac-OS*/
            perror("cannot execute vmmap (Mac-OS)");
        exit(1);
    }
    waitpid (pid,NULL,0);
 }

void fmemory(int opcion, memoryList *memoryList) {

    int local1 = 1, local2 = 2, local3 = 3;

    switch (opcion) {
        case FUNCS:
            printf("Funciones programa\t%p,\t%p,\t%p\n", (void *)authors, (void *)historic, (void *)help );
            printf("Funciones libreria\t%p,\t%p,\t%p\n", (void *)printf, (void *)malloc, (void *)scanf );
            break;
        case VARS:
            printf("Variables locales\t%p,\t%p,\t%p\n", (void *)&local1, (void *)&local2, (void *)&local3 );
            printf("Variables globales\t%p,\t%p,\t%p\n", (void *)&global_inicializada_1, (void *)&global_inicializada_2, (void *)&global_inicializada_3 );
            printf("Var (N.I.)globales\t%p,\t%p,\t%p\n", (void *)&global1, (void *)&global2, (void *)&global3 );
            printf("Variables staticas\t%p,\t%p,\t%p\n", (void *)&estatica_inicializada_1, (void *)&estatica_inicializada_2, (void *)&estatica_inicializada_3 );
            printf("Var (N.I.)staticas\t%p,\t%p,\t%p\n", (void *)&estatica1, (void *)&estatica2, (void *)&estatica3 );
            break;
        case BLOCKS:
            printMemoryList(getpid(), *memoryList);
            break;
        case ALL:
            fmemory(VARS, memoryList);
            fmemory(FUNCS, memoryList);
            fmemory(BLOCKS, memoryList);
            break;
        case PMAP:
            Do_pmap();
            break;
    }
}

ssize_t Leerfichero(char *file, void *p, size_t cont) {
    struct stat s;
    ssize_t  n;
    int df,aux;

    if (stat (file,&s)==-1 || (df=open(file,O_RDONLY))==-1) {
        return -1;
    }
    if (cont==-1) {
        cont=s.st_size;
    }
    if ((n=read(df,p,cont))==-1){
        aux=errno;
        close(df);
        errno=aux;
        return -1;
    }
    close (df);
    return n;
}

ssize_t LeerFicheroDescriptor(int desc, void *p, size_t cont) {
    struct stat s;
    ssize_t n;
    int aux;

    if (fstat(desc, &s)==-1) {
        return -1;
    }
    if (cont==-1) {
        cont = s.st_size;
    }
    if ((n = read(desc,p,cont))==-1){
        aux=errno;
        close(desc);
        errno=aux;
        return -1;
    }
    close(desc);
    return n;
}

void freadfile(char *file, char *addr, int cont) {
    void *p = cadtop(addr);

    if (p != NULL) {
        ssize_t n = Leerfichero(file, p, cont);
        if (n == -1) { perror("Imposible leer fichero.\n"); }
        else {
            printf("Leidos %lld bytes de %s en %p\n", (long long)n, file, p);
        }
    } else {
        perror("Direccion de memoria inválida.\n");
    }
}

void fread0(int desc, char *addr, int cont, fileList *fileList) {
    filePos filePos = searchFileNum(desc, *fileList);
    if (filePos == NULL){
        perror("No se puede acceder al archivo\n");
    }else {
        void *p = cadtop(addr);

        if (p != NULL) {
            ssize_t n = LeerFicheroDescriptor(desc, p, cont);
            if (n == -1) { perror("Imposible leer fichero.\n"); }
            else {
                printf("Leidos %lld bytes desde descriptor %d en %p\n", (long long)n, desc, p);
            }
        } else {
            perror("Direccion de memoria inválida.\n");
        }
    }
}

ssize_t Escribirfichero(char *file, void *p, size_t cont) {
    ssize_t n;
    int df, aux;

    if ((df = open(file, O_WRONLY | O_TRUNC))==-1) {
        return -1;
    }

    if ((n = write(df, p, cont))==-1) {
        aux=errno;
        close(df);
        errno=aux;
        return -1;
    }
    close (df);
    return n;
}

ssize_t EscribirFicheroDescriptor(int desc, void *p, size_t cont) {
    ssize_t n;
    int aux;

    if ((n = write(desc, p, cont))==-1) {
        aux=errno;
        close(desc);
        errno=aux;
        return -1;
    }
    close(desc);
    return n;
}

void fwritefile(char *file, char *addr, int cont) {
    void *p = cadtop(addr);

    if (p != NULL) {
        ssize_t n = Escribirfichero(file, p, cont);
        if (n == -1){ perror("Imposible leer fichero\n.");}
        else {
            printf("Escritos %lld bytes en %s desde %p\n", (long long)n, file, p);
        }
    } else {
        perror("Direccion de memoria inválida.\n");
    }
}

void fwrite0(int desc, char *addr, int cont, fileList *fileList) {
    filePos filePos = searchFileNum(desc, *fileList);
    if (filePos == NULL){
        perror("No se puede acceder al archivo\n");
    }else {
        void *p = cadtop(addr);

        if (p != NULL) {
            ssize_t n = EscribirFicheroDescriptor(desc, p, cont);
            if (n == -1) { perror("Imposible leer fichero.\n"); }
            else {
                printf("Escritos %lld bytes en descriptor %d en %p\n", (long long)n, desc, p);
            }
        } else {
            perror("Direccion de memoria inválida.\n");
        }
    }
}

void recurse (int n) {

    char automatico[2048];
    static char estatico[2048];

    printf("parametro:   %d(%p) array %p, arr estatico %p\n", n, &n, automatico, estatico);

    if (n > 0) {
       recurse(n - 1);
    }
}

void fgetuid() {
    uid_t uid_real = getuid();
    uid_t uid_efectivo = geteuid();

    struct passwd *usuario_real = getpwuid(uid_real);
    char *name_real = usuario_real->pw_name;

    struct passwd *usuario_efectivo = getpwuid(uid_efectivo);
    char *name_efectivo = usuario_efectivo->pw_name;

    printf("Credencial real: %d, (%s)\n", uid_real, name_real);
    printf("Credencial efectiva: %d, (%s)\n", uid_efectivo, name_efectivo);
}

void fsetuid(int login, char *new_uid) {
    uid_t uid;
    struct passwd *pwd;

    if (login) {
        pwd = getpwnam(new_uid);
        if (pwd == NULL) {
            printf("Usuario no existente %s\n", new_uid);
            return;
        }
        uid = pwd->pw_uid;
    } else {
        char *final;
        uid = strtol(new_uid, &final, 10);
        if (*final != '\0') {
            printf("Error: '%s' no es un UID válido.\n", new_uid);
            return;
        }
    }

    if (setuid(uid) == -1) {
        perror("Imposible cambiar credencial\n");
        exit(EXIT_FAILURE);
    }

    printf("Nuevo UID: %d\n", uid);
}

void fenviron(int opcion, char **main_environ) {
    switch (opcion) {
        case ENVIRON:
            //main arg3
            for (char **env = main_environ; *env != NULL; env++) {
                printf("%p->main arg3[%ld]=(%p) %s\n", (void *)env, env - main_environ, (void *)*env, *env);
            }
            //environ
            for (char **env = environ; *env != NULL; env++) {
                printf("%p->environ[%ld]=(%p) %s\n", (void *)env, env - environ, (void *)*env, *env);
            }
            break;
        case ADDR:
            printf("environ:   %p (almacenado en %p)\n", (void *)environ, (void *)&environ);
            printf("main arg3: %p (almacenado en %p)\n", (void *)main_environ, (void *)&main_environ);
            break;
    }
}

int procesarEntrada(command command, char *commands[MAX_COMMANDS], commandList *commandList, fileList *fileList, memoryList *memoryList, char *main_environ[]) {
    int i = 0;

    if (strcmp(command.comando, commands[0]) == 0) {
        if (command.i == 1) {
            authors(NAMEANDLOGIN);
        } else if (strcmp(command.opcion, "-n") == 0) {
            authors(NAME);
        } else if (strcmp(command.opcion, "-l") == 0) {
            authors(LOGIN);
        } else {
            authors(ERROR);
        }
        insertCommand(command, commandList);
        return i;
    } //authors

    if (strcmp(command.comando, commands[1]) == 0){
        if (command.i == 1){
            pid();
            insertCommand(command, commandList);
        }else{
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } //pid

    if (strcmp(command.comando, commands[2]) == 0){
        if (command.i == 1){
            ppid();
            insertCommand(command, commandList);
        }else{
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } //ppid

    if (strcmp(command.comando, commands[3]) == 0) {
        if (command.i == 1) {
            cd(CWD, command.opcion);
            insertCommand(command, commandList);
        }else if (command.i == 2) {
            cd(CD, command.opcion);
            insertCommand(command, commandList);
        }else {
            cd(ERROR, command.opcion);
        }
        return i;
    } //cd

    if (strcmp(command.comando, commands[4]) == 0) { // date
        if (command.i == 1) {
            date(DATEANDTIME);
        }else {
            if (strcmp(command.opcion, "-t") == 0) {
                date(TIME);
            }else {
                if (strcmp(command.opcion, "-d") == 0) {
                    date(DATE);
                }else {
                    date(ERROR);
                }
            }
        }
        insertCommand(command, commandList);
        return i;
    } //date

    if (strcmp(command.comando, commands[5]) == 0) { // historic
        if (command.i == 1) {
            historic(PRINT, 0, commands, commandList, fileList, memoryList, main_environ);
        }else {
            int num;
            if (sscanf(command.opcion, "%d", &num) == 1) {
                if (num >= 0) {
                    historic(EX, num, commands, commandList, fileList, memoryList, main_environ);
                    insertCommand(command, commandList);
                }else {
                    historic(PRINTN, num, commands, commandList, fileList, memoryList, main_environ);
                    insertCommand(command, commandList);
                }
            }else {
                historic(ERROR, num, commands, commandList, fileList, memoryList, main_environ);
            }
        }
        return i;
    } //historic

    if (strcmp(command.comando, commands[6]) == 0) {
       if (command.i == 1) {
           openf(NO_MODE, "", fileList);
       }else if (command.i == 3) {
           if(strcmp(command.modo, "cr") == 0) {
               openf(CR, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ap") == 0) {
               openf(AP, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ex") == 0) {
               openf(EX0, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "ro") == 0) {
               openf(RO, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "rw") == 0) {
               openf(RW, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "wo") == 0) {
               openf(WO, command.opcion, fileList);
               insertCommand(command, commandList);
           }else if (strcmp(command.modo, "tr") == 0) {
               openf(TR, command.opcion, fileList);
               insertCommand(command, commandList);
           }else {
               openf(ERROR, "a", fileList);
           }
       }else {
           openf(ERROR, "b", fileList);
       }
        return i;
    } //open

    if (strcmp(command.comando, commands[7]) == 0) {
        if (command.i == 2) {
            int desc;
            sscanf(command.opcion, "%d", &desc);
            closef(desc, fileList);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } //close

    if (strcmp(command.comando, commands[8]) == 0) {
        if (command.i == 2) {
            int desc;
            sscanf(command.opcion, "%d", &desc);
            dupf(desc, fileList);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_COMMAND);
        }
        return i;
    } //dup

    if (strcmp(command.comando, commands[9]) == 0) {
        if (command.i == 1) {
            infosys();
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } //infosys

    if (strcmp(command.comando, commands[10]) == 0) {
        if (command.i == 1) {
            help(49, commands);
        }else {
            for (int j = 0; j < MAX_COMMANDS; j++) {
                if (strcmp(command.opcion, commands[j]) == 0) {
                    help(j, commands);
                    return i;
                }
            }
            printf("Opción no válida.\n");
        }
        insertCommand(command, commandList);
        return i;
    } //help

    if ((strcmp(command.comando, commands[11]) == 0) || // exit
       (strcmp(command.comando, commands[12]) == 0) || // quit
       (strcmp(command.comando, commands[13]) == 0)) { //bye
        if (command.i == 1) {
            i = 1;
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    }

    if (strcmp(command.comando, commands[14]) == 0) {
        if (command.i == 2) {
            makeFile(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // makefile

    if (strcmp(command.comando, commands[15]) == 0) {
        if (command.i == 2) {
            makeDir(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // makedir

    if (strcmp(command.comando, commands[16]) == 0){
        if (command.i == 2) {
            listFile(command.opcion, NO_MODE);
            insertCommand(command, commandList);
        }else {
            if (command.i == 3) {
                if (strcmp(command.opcion, "-long") == 0) {
                    listFile(command.modo, LONG);
                    insertCommand(command, commandList);
                }else {
                    if (strcmp(command.opcion, "-acc") == 0) {
                        listFile(command.modo, ACC);
                        insertCommand(command, commandList);
                    }else {
                        if (strcmp(command.opcion, "-link") == 0) {
                            listFile(command.modo, LINK);
                            insertCommand(command, commandList);
                        }else {
                            imprimirError(NO_VALID_OPTION);
                        }
                    }
                }
            }
        }
        return i;
    } // listFile

    if (strcmp(command.comando, commands[17]) == 0) {
        if (command.i == 1) {
            cwd();
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // cwd

    if (strcmp(command.comando, commands[18]) == 0) {
        if (command.i == 2) {
            listDir(command.opcion, NO_MODE);
            insertCommand(command, commandList);
        }else {
            if (command.i == 3) {
                if (strcmp(command.opcion, "-long") == 0) {
                    listDir(command.modo, LONG);
                    insertCommand(command, commandList);
                }else {
                    if (strcmp(command.opcion, "-acc") == 0) {
                        listDir(command.modo, ACC);
                        insertCommand(command, commandList);
                    }else {
                        if (strcmp(command.opcion, "-link") == 0) {
                            listDir(command.modo, LINK);
                            insertCommand(command, commandList);
                        }else {
                            if (strcmp(command.opcion, "-hid") == 0) {
                                listDir(command.modo, HID);
                                insertCommand(command, commandList);
                            }else {
                                imprimirError(NO_VALID_OPTION);
                            }
                        }
                    }
                }
            }
        }
        return i;
    } // listdir

    if (strcmp(command.comando, commands[19]) == 0) {
        if (command.i == 2) {
            recList(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // reclist

    if (strcmp(command.comando, commands[20]) == 0) {
        if (command.i == 2) {
            revList(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // revlist

    if (strcmp(command.comando, commands[21]) == 0) {
        if (command.i == 2) {
            erase(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // erase

    if (strcmp(command.comando, commands[22]) == 0) {
        if (command.i == 2) {
            delRec(command.opcion);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // delRec

    if (strcmp(command.comando, commands[23]) == 0) {
        if (command.i == 1) {
            allocate(PRINTD, 0, "", "", 0, memoryList);
        }else {
            if (command.i == 3) {
                if (strcmp(command.opcion , "-malloc") == 0) {
                    int n = atoi(command.modo);
                    allocate(MALLOC, n, "", "", "", memoryList);
                    insertCommand(command, commandList);
                }else {
                    if (strcmp(command.opcion, "-shared") == 0) {
                        int n = atoi(command.modo);
                        allocate(ATTACH_SHARED, 0, "", "", n, memoryList);
                        insertCommand(command, commandList);
                    }else {
                        imprimirError(NO_VALID_OPTION);
                    }
                }
            }else {
                if (command.i == 4) {
                    if (strcmp(command.opcion, "-mmap") == 0) {
                        allocate(MMAP, 0, command.modo, command.procedimiento , "", memoryList);
                        insertCommand(command, commandList);
                    }else {
                        if (strcmp(command.opcion, "-createshared") == 0) {
                            int n = atoi(command.procedimiento);
                            int m = atoi(command.modo);
                            allocate(CREATE_SHARED, n, "", "", m, memoryList);
                            insertCommand(command, commandList);
                        }
                    }
                }else {
                    imprimirError(NO_VALID_OPTION);
                }
            }
        }
        return i;
    } // allocate

    if (strcmp(command.comando, commands[24]) == 0) {
        if (command.i == 1) {
            deallocate(PRINTD, 0, "", "", 0, memoryList);
            insertCommand(command, commandList);
        }else {
            if (command.i == 2) {
                void *address = (void *)strtoull(command.opcion, NULL, 16);
                deallocate(ADDR, 0, "", address, "", memoryList);
                insertCommand(command, commandList);
            }else {
                if (command. i == 3) {
                    if (strcmp(command.opcion , "-malloc") == 0) {
                        int n = atoi(command.modo);
                        deallocate(MALLOC, n, "", "", "", memoryList);
                        insertCommand(command, commandList);
                    }else {
                        if (strcmp(command.opcion, "-mmap") == 0) {
                            deallocate(MMAP, 0, command.modo, "", 0, memoryList);
                            insertCommand(command, commandList);
                        }else {
                            if (strcmp(command.opcion, "-shared") == 0) {
                                int n = atoi(command.modo);
                                deallocate(SHARED, 0, "", "", n, memoryList);
                                insertCommand(command, commandList);
                            }else {
                                if (strcmp(command.opcion, "-delkey") == 0) {
                                    int n = atoi(command.modo);
                                    deallocate(DELKEY, 0, "", "", n, memoryList);
                                    insertCommand(command, commandList);
                                }else {
                                    imprimirError(NO_VALID_OPTION);
                                }
                            }
                        }
                    }
                }else {
                    imprimirError(NO_VALID_OPTION);
                }
            }
        }
        return i;
    } // deallocate

    if (strcmp(command.comando, commands[25]) == 0) {
        if(command.i == 4) {
            int n = atoi(command.modo);
            memfill(command.opcion, n, command.procedimiento[0]);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // memfill

    if (strcmp(command.comando, commands[26]) == 0) {
        if (command.i ==3) {
            int n = atoi(command.modo);
            memdump(command.opcion, n);
            insertCommand(command, commandList);
        }else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // memdump

    if (strcmp(command.comando, commands[27]) == 0) {
        if (command.i == 1) {
            fmemory(ALL, memoryList);
            insertCommand(command, commandList);
        } else if (command.i == 2) {
            if (strcmp(command.opcion , "-funcs") == 0) {
                fmemory(FUNCS, memoryList);
                insertCommand(command, commandList);
            } else if (strcmp(command.opcion , "-vars") == 0) {
                fmemory(VARS, memoryList);
                insertCommand(command, commandList);
            } else if (strcmp(command.opcion , "-blocks") == 0) {
                fmemory(BLOCKS, memoryList);
                insertCommand(command, commandList);
            } else if (strcmp(command.opcion , "-all") == 0) {
                fmemory(ALL, memoryList);
                insertCommand(command, commandList);
            } else if (strcmp(command.opcion , "-pmap") == 0) {
                fmemory(PMAP, memoryList);
                insertCommand(command, commandList);
            }
        } else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // memory

    if (strcmp(command.comando, commands[28]) == 0) {
        if (command.i == 4) {
            int n = atoi(command.procedimiento);
            freadfile(command.opcion, command.modo, n);
            insertCommand(command, commandList);
        } else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // readfile

    if (strcmp(command.comando, commands[29]) == 0) {
        if (command.i == 4) {
            int n = atoi(command.procedimiento);
            fwritefile(command.opcion, command.modo, n);
            insertCommand(command, commandList);
        } else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // writefile

    if (strcmp(command.comando, commands[30]) == 0) {
        if (command.i == 4) {
            int desc = atoi(command.opcion);
            int n = atoi(command.procedimiento);
            fread(desc, command.modo, n, fileList);
            insertCommand(command, commandList);
        } else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // read

    if (strcmp(command.comando, commands[31]) == 0) {
        if (command.i == 4) {
            int desc = atoi(command.opcion);
            int n = atoi(command.procedimiento);
            fwrite(desc, command.modo, n, fileList);
            insertCommand(command, commandList);
        } else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // write

    if (strcmp(command.comando, commands[32]) == 0) {
        if(command.i == 2) {
            if (command.opcion >= 0) {
                int n = atoi(command.opcion);
                recurse(n);
                insertCommand(command, commandList);
            }else {
                imprimirError(NO_VALID_OPTION);
            }
        } else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    } // recurse

    if (strcmp(command.comando, commands[33]) == 0) {
        if (command.i == 1) {
            fgetuid();
            insertCommand(command, commandList);
        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//getuid

    if (strcmp(command.comando, commands[34]) == 0) {
        if (command.i == 2) {
            fsetuid(0, command.opcion);
            insertCommand(command, commandList);
        }else if (command.i == 3) {
            if (strcmp(command.opcion, "-l") == 0) {
                fsetuid(1, command.modo);
                insertCommand(command, commandList);
            } else {
                imprimirError(NO_VALID_OPTION);
            }
        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//setuid

    if (strcmp(command.comando, commands[35]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//showvar

    if (strcmp(command.comando, commands[36]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//changevar

    if (strcmp(command.comando, commands[37]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }// subsvar

    if (strcmp(command.comando, commands[38]) == 0) {
        if (command.i == 1) {
            fenviron(ENVIRON, main_environ);
            insertCommand(command, commandList);
        } else if (command.i == 2) {
            if (strcmp(command.opcion, "-environ") == 0) {
                fenviron(ENVIRON, main_environ);
                insertCommand(command, commandList);
            } else if (strcmp(command.opcion, "-addr") == 0) {
                fenviron(ADDR, main_environ);
                insertCommand(command, commandList);
            } else {
                imprimirError(NO_VALID_OPTION);
            }
        } else {
            imprimirError(NO_VALID_OPTION);
        }
        return i;
    }// environ

    if (strcmp(command.comando, commands[39]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//fork

    if (strcmp(command.comando, commands[40]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//search

    if (strcmp(command.comando, commands[41]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//exec

    if (strcmp(command.comando, commands[42]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//execpri

    if (strcmp(command.comando, commands[43]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//fg

    if (strcmp(command.comando, commands[44]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//fgpri

    if (strcmp(command.comando, commands[45]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//back

    if (strcmp(command.comando, commands[46]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//backpri

    if (strcmp(command.comando, commands[47]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//listjobs

    if (strcmp(command.comando, commands[48]) == 0) {
        if (command.i == 1) {

        } else {
            imprimirError(NO_VALID_OPTION);
        }

        return i;
    }//deljobs

    imprimirError(NO_VALID_COMMAND);
    return i;
}

int main(int argc, char *argv[], char *main_environ[]) {
    bool terminado = false;
    commandList commandList;
    createEmptyCommandList(&commandList);
    fileList fileList;
    createEmptyFileList(&fileList);
    memoryList memoryList;
    createEmptyMemoryList(&memoryList);
    searchList searchList;
    createEmptySearchList(&searchList);
    processList processList;
    createEmptyProcessList(&processList);

    char *commands[MAX_COMMANDS] = {
        "authors", "pid", "ppid", "cd", "date", "historic", "open", "close",
        "dup", "infosys", "help", "exit", "quit", "bye", "makefile", "makedir",
        "listfile", "cwd", "listdir", "reclist", "revlist", "erase", "delrec",
        "allocate", "deallocate", "memfill", "memdump", "memory", "readfile",
        "writefile", "read", "write", "recurse", "getuid", "setuid", "showvar",
        "changevar", "subsvar", "environ", "fork", "search", "exec", "execpri",
        "fg", "fgpri", "back", "backpri", "listjobs", "deljobs"
    };

    while (!terminado) {
        imprimirPrompt();
        command command = leerEntrada();

        if (command.i > 0) {
            int i = procesarEntrada(command, commands, &commandList, &fileList, &memoryList, main_environ);

            if (i == 1) {
                terminado = true;
            }
        }
    }
    freeCommandList(&commandList);
    freeFileList(&fileList);
    freeMemoryList(&memoryList);
    freeSearchList(&searchList);
    freeProcessList(&processList);
    return 0;
}