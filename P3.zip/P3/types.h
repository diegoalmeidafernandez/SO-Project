#ifndef TYPES_H
#define TYPES_H
#define MAXDIR 50
#define MAX_TROZOS 100
#define MAX_STRING 100
#define MAX_COMMANDS 49
#define NAME0 "Diego Adrián Almeida Fernández"
#define NAME1 "Juan Melón Domínguez"
#define LOGIN0 "diego.almeida.fernandez@udc.es"
#define LOGIN1 "j.melon@udc.es"
#define NO_VALID_COMMAND 0
#define NO_VALID_OPTION 1
#define ERROR (-1)
#define NAMEANDLOGIN 0
#define NAME 1
#define LOGIN 2
#define CWD 0
#define CD 1
#define DATEANDTIME 0
#define TIME 1
#define DATE 2
#define PRINT 0
#define EX 1
#define PRINTN 2
#define NO_MODE 0
#define CR 1
#define AP 2
#define EX0 3
#define RO 4
#define RW 5
#define WO 6
#define TR 7
#define LONG 1
#define ACC 2
#define LINK 3
#define HID 4
#define MALLOC 0
#define MMAP 1
#define CREATE_SHARED 2
#define ATTACH_SHARED 3
#define SHARED 2
#define DELKEY 3
#define ADDR 4
#define PRINTD 5
#define FUNCS 0
#define VARS 1
#define BLOCKS 2
#define ALL 3
#define PMAP 4
#define ENVIRON 1
#define PRINTS 4
#define CLEAR 0
#define PATH 1
#define ADD 2
#define DEL 3

#include <ctype.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/wait.h>

typedef struct command{
    int i;
    char comando[50];
    char opcion[50];
    char modo[50];
    char procedimiento[50];
}command;

typedef struct Tfile {
    int descriptor;
    char filename[20];
    char openningMode[2];
}Tfile;

typedef struct TMemory {
    void *adress;
    int size;
    int clave;
    int decr;
    char type[10];
    char fileName[256];
    char permissions[10];
    char timestamp[20];
}TMemory;

typedef struct Tsearch {
    char dir[MAXDIR];
}Tsearch;

typedef struct Tprocess {
    int a;
}Tprocess;

#endif //TYPES_H